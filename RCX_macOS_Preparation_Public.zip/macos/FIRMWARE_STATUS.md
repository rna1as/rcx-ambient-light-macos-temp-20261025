# Status firmware yang dibawa

Tidak ada firmware yang di-flash atau diubah. Build aplikasi Mac tidak memerlukan build/upload firmware.

| Sumber | Deklarasi | Peran di port Mac |
|---|---|---|
| `source-budget/RCXFirmware` | 1.7.0-R/O, MAX=350 | snapshot historis SKU Budget yang benar-benar ada saat inventaris; bukan baseline firmware produksi terbaru |
| `source-premium/RCXFirmware` | 1.7.2-R/O, MAX=350 | referensi pembaruan firmware/WebUI terbaru yang disetujui dalam source aktif, termasuk perubahan 19 Oktober |

Versi di tabel adalah deklarasi source, bukan hasil pembacaan controller. Dokumen Windows root menyebut firmware produksi 1.7.2; source-budget masih tertinggal pada deklarasi 1.7.0. Selisih itu dipertahankan dan dinyatakan, bukan disembunyikan dengan mengganti versi atau mengubah source Windows. Untuk meninjau perubahan firmware terbaru yang ikut dibawa, gunakan source Premium 1.7.2 beserta RCXAuth pada tree yang sama. Ini merupakan source firmware yang sama terlepas dari sistem operasi host; tidak ada kebutuhan membuat firmware khusus macOS.

Firmware Premium mempertahankan Single Color/color wheel, Effects, Settings dengan sumber PC/WebUI, pemindaian SSID, koneksi Wi-Fi rumah bersamaan dengan AP, pilihan bahasa dan OTA; migrasi preferensi/EEPROM serta identitas controller tetap diwarisi dari source aktif. Seluruh file firmware snapshot dicek hash terhadap sumber asal oleh verifier. Public trust root Qt dan Go juga sama byte per byte.

DMG pembeli tidak memuat binary atau source firmware/flasher; source firmware tetap ada pada paket **persiapan pengembang** ini untuk menjaga handoff lengkap. Jangan menjalankan OTA/flash untuk memvalidasi aplikasi Mac pada unit produksi.
