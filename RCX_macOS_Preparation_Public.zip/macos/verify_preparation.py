"""Offline checks. Never opens a controller, starts RCX or writes production data."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--go',help='Go executable; runs offline Go tests plus Darwin cross-compilation')
    p.add_argument('--check-protected',action='store_true',help='Verify every original inventoried file; requires the original Windows workspace')
    a=p.parse_args()
    reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    report={'nativeMacBuild':'NOT RUN','macHardwareTests':'NOT RUN','firmwareFlash':'NOT RUN','checks':[]}
    def check(name,ok,detail=None):
        report['checks'].append({'name':name,'ok':ok,'detail':detail});print(name, 'PASS' if ok else 'FAIL')
    baseline=json.loads((ROOT/'BASELINE.json').read_text()) if (ROOT/'BASELINE.json').is_file() else None
    manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
    originals={x['path']:x for x in (baseline['files'] if baseline else manifest['originals'])}
    check('isolated source manifest',all((ROOT/x['path']).is_file() and sha(ROOT/x['path'])==x['sha256'] for x in manifest['files']))
    for sku in ('budget','premium'):
        source=ROOT/('source-'+sku)
        firmware=list((source/'RCXFirmware').rglob('*'))
        check(sku+' firmware snapshot',all(sha(f)==originals['source-'+sku+'/'+f.relative_to(source).as_posix()]['sha256'] for f in firmware if f.is_file()))
        for rel in ['RCXAuth/trust.h','RCXSetup/trust.go']:
            check(sku+' unchanged trust '+rel,sha(source/rel)==originals['source-'+sku+'/'+rel]['sha256'])
        mainfile=(source/'RCXSetup/main.go').read_text()
        check(sku+' macOS capture selection','Grabber=MacAVFoundation' in mainfile and 'Grabber=DDupl' not in mainfile)
        check(sku+' portable crypto','SecRandomCopyBytes' in (source/'RCXAuth/auth_qt.hpp').read_text())
        if a.go:
            env=os.environ.copy();env.update(GOCACHE=str(ROOT/'cache/go'),GOPATH=str(ROOT/'cache/gopath'),GOFLAGS='-buildvcs=false',CGO_ENABLED='0')
            result=subprocess.run([a.go,'test','-count=1','-v','-tags','rcx_portable_test','./...'],cwd=source/'RCXSetup',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            (reports/(sku+'-go-tests.txt')).write_text(result.stdout)
            check(sku+' Go offline tests',result.returncode==0,result.stdout[-1500:])
            for arch in ('amd64','arm64'):
                env.update(GOOS='darwin',GOARCH=arch)
                dest=reports/(sku+'-darwin-'+arch+'-tests')
                result=subprocess.run([a.go,'test','-c','-o',str(dest),'.'],cwd=source/'RCXSetup',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                check(sku+' Darwin '+arch+' Go test compilation',result.returncode==0,result.stdout)
                dest.unlink(missing_ok=True)
            # Reset before the next SKU's runnable Windows tests.
            env.pop('GOOS',None);env.pop('GOARCH',None)
    if a.check_protected:
        if baseline is None:
            check('original Windows baseline available',False,'--check-protected must run in the original Windows workspace')
            (reports/'PREPARATION_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
            return 1
        changed=[]
        for row in baseline['files']:
            f=ROOT.parent/row['path']
            if not f.is_file() or sha(f)!=row['sha256']:changed.append(row['path'])
        check('original Windows sources/releases/evidence unchanged',not changed,changed)
    report['success']=all(x['ok'] for x in report['checks'])
    (reports/'PREPARATION_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['success'] else 1

if __name__=='__main__':sys.exit(main())
