"""Create a Mac-transfer source archive, with no Windows production artifacts."""
from pathlib import Path
import hashlib
import zipfile

ROOT=Path(__file__).resolve().parent
allowed_files={
    'README_ID.md','INVENTORY.md','MAC_TEST_CHECKLIST.md','FIRMWARE_STATUS.md',
    'build_macos.py','verify_preparation.py','package_preparation.py',
    'SOURCE_MANIFEST.json','.gitignore',
    'platform_macos.go','SOURCE_MANIFEST.json','.gitignore',
}
allowed_dirs={'source-budget','source-premium','native','reports','.github'}
archive=ROOT/'RCX_macOS_Preparation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(ROOT.rglob('*')):
        if not f.is_file():continue
        rel=f.relative_to(ROOT)
        if rel.parts[0] not in allowed_dirs and rel.as_posix() not in allowed_files:continue
        if '__pycache__' in rel.parts:continue
        if rel.parts[0]=='reports' and f.suffix not in {'.json','.txt'}:continue
        z.write(f,'macos/'+rel.as_posix())
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('Archive CRC failure: '+bad)
checksum=hashlib.sha256(archive.read_bytes()).hexdigest()
(ROOT/'PREPARATION_SHA256SUMS.txt').write_text(checksum+'  '+archive.name+'\n')
print(archive)
print('SHA-256:',checksum)
