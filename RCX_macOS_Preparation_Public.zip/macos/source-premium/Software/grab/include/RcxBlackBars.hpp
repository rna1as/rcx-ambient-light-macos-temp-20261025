// RCX additions, GPL-3.0-or-later. Symmetric letterbox/pillarbox with temporal stability.
#pragma once
#include <QRect>
#include <QRgb>
#include <functional>
class RcxBlackBars {
    QRect m_active, m_candidate; int m_count=0;
public:
    QRect update(int w,int h,const std::function<QRgb(int,int)> &pixel) {
        const QRect full(0,0,w,h);
        if (w<32||h<32) return full;
        auto dark=[](QRgb c){return qMax(qRed(c),qMax(qGreen(c),qBlue(c)))<=8;};
        auto row=[&](int y){int n=0;for(int i=1;i<=40;++i)n+=dark(pixel(i*(w-1)/41,y));return n>=39;};
        int top=0,bottom=0;
        while(top<h*3/10&&row(top))++top;
        while(bottom<h*3/10&&row(h-1-bottom))++bottom;
        if(top<4||bottom<4||qAbs(top-bottom)>qMax(4,h/100)||top>=h*3/10||bottom>=h*3/10)top=bottom=0;
        auto col=[&](int x){int n=0;for(int i=1;i<=40;++i)n+=dark(pixel(x,top+i*(h-top-bottom-1)/41));return n>=39;};
        int left=0,right=0;
        while(left<w*3/10&&col(left))++left;
        while(right<w*3/10&&col(w-1-right))++right;
        if(left<4||right<4||qAbs(left-right)>qMax(4,w/100)||left>=w*3/10||right>=w*3/10)left=right=0;
        QRect candidate(left,top,w-left-right,h-top-bottom);
        if(m_active.size().isEmpty()||!full.contains(m_active))m_active=full;
        if(candidate==m_candidate)++m_count;else{m_candidate=candidate;m_count=1;}
        if(m_count>=(candidate==full?12:8))m_active=candidate;
        return m_active;
    }
    static QRect remap(const QRect &zone,const QRect &full,const QRect &active) {
        const int x=active.x()+qRound(double(zone.x()-full.x())*active.width()/full.width());
        const int y=active.y()+qRound(double(zone.y()-full.y())*active.height()/full.height());
        return QRect(x,y,qMax(1,qRound(double(zone.width())*active.width()/full.width())),qMax(1,qRound(double(zone.height())*active.height()/full.height()))).intersected(active);
    }
};
