<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="id_ID">
 <context>
  <name>ApiServer</name>
  <message>
   <location filename="../../src/ApiServer.cpp" line="1281" />
   <source>API server unable to start (port: %1): %2.</source>
   <translation>Server API gagal berjalan (port %1): %2.</translation>
  </message>
 </context>
 <context>
  <name>ConfigureDevicePage</name>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="17" />
   <source>Device configuration</source>
   <translation>Konfigurasi perangkat</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="27" />
   <source>Baud rate</source>
   <translation>Kecepatan baud</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="92" />
   <source>Serial port</source>
   <translation>Port serial</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="100" />
   <source>RGB</source>
   <translation>RGB</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="105" />
   <source>RBG</source>
   <translation>RBG</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="110" />
   <source>BGR</source>
   <translation>BGR</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="115" />
   <source>BRG</source>
   <translation>BRG</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="120" />
   <source>GRB</source>
   <translation>GRB</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="125" />
   <source>GBR</source>
   <translation>GBR</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="133" />
   <source>Color format</source>
   <translation>Format warna</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePage.ui" line="146" />
   <source>Make sure to match your device's baud rate!
Warning: Values larger than 115200 are entirely untested. Use at your own risk.</source>
   <translation>Sesuaikan baud dengan perangkat. RCX menggunakan 921600; kecepatan perangkat lain perlu diuji.</translation>
  </message>
 </context>
 <context>
  <name>ConfigureDevicePowerPage</name>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="17" />
   <source>Device configuration</source>
   <translation>Konfigurasi perangkat</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="40" />
   <source>mAmps</source>
   <translation>mAmps</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="47" />
   <source>Amps</source>
   <translation>Amps</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="74" />
   <source>Power Supply current limit</source>
   <translation>Batas arus catu daya</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="81" />
   <source>Single LED current</source>
   <translation>Arus satu LED</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureDevicePowerPage.ui" line="133" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align="justify"&gt;If your LED power supply cannot provide enough current AND you know your LED's current requirements (check datasheet if needed) you can limit the current here. This will reduce the overall brightness on current hungry scenes. &lt;/p&gt;&lt;p align="justify"&gt;Leave Power Supply current limit at &amp;quot;0&amp;quot; to disable limiting.&lt;/p&gt;&lt;p align="justify"&gt;&lt;span style=" font-weight:600;"&gt;Warning&lt;/span&gt;: Power Supply current limit value might not match exactly your power supply so adjust as necessary.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Bila catu daya tidak mencukupi, atur batas arus sesuai kebutuhan LED. Ini menurunkan kecerahan pada adegan terang. Nilai 0 menonaktifkan batas; sesuaikan dengan spesifikasi catu daya.&lt;/p&gt;</translation>
  </message>
 </context>
 <context>
  <name>ConfigureUdpDevicePage</name>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="17" />
   <source>Device configuration</source>
   <translation>Konfigurasi perangkat</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="27" />
   <source>Address</source>
   <translation>Alamat</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="50" />
   <source>Timeout</source>
   <translation>Batas waktu</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="99" />
   <source>Port</source>
   <translation>Port</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ConfigureUdpDevicePage.ui" line="106" />
   <source>Timeout in seconds after which the device returns to normal mode if no data is sent by Prismatik.
Setting this to 255 disables the timeout and the device will keep the last received colors if no more data is sent.
It's recommended to not use "Send data only if colors changed" setting with a short timeout value.</source>
   <translation>Jeda sebelum perangkat kembali ke mode normal tanpa data Prismatik. Nilai 255 menonaktifkan jeda. Untuk jeda pendek, kirim setiap frame.</translation>
  </message>
 </context>
 <context>
  <name>GlobalColorCoefPage</name>
  <message>
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="17" />
   <source>White balance</source>
   <translation>Keseimbangan putih</translation>
  </message>
  <message>
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="52" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Adjust the color channels until your wall has the same color as your screen.&lt;br/&gt;
You can do it either via the gear icon of the each zone OR via the global color sliders / Color Temperature (CT) slider that adjusts all 3 channels at once.&lt;br/&gt;
&lt;b&gt;Warning:&lt;/b&gt; the global sliders will override manually set values for individual zones! So do global first, then adjust each zone if needed.
&lt;/p&gt;
&lt;p&gt;
&lt;table border="0" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;" cellspacing="0" cellpadding="0"&gt;&lt;tr&gt;&lt;td&gt;You can also adjust the colors for each zone individually later on using the gear icon of the corresponding grab widget.&lt;br/&gt;Mode tab &gt; Screen grabbing mode &gt; Grab widget adjustment&lt;/td&gt;&lt;td style=" padding-left:2;"&gt;&lt;img src=":/buttons/settings_24px.png" width="16"/&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Atur kanal warna sampai warna dinding sesuai layar. Pengaturan global menimpa nilai zona individual; atur global dahulu, lalu per zona.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="654" />
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="853" />
   <source>&lt;b&gt;Color Temperature&lt;/b&gt;
&lt;br&gt;
3-in-1 helper slider to adjust white point</source>
   <translation>&lt;b&gt;Suhu warna&lt;/b&gt;&lt;br&gt;Atur titik putih ketiga kanal sekaligus</translation>
  </message>
  <message>
   <location filename="../../src/wizard/GlobalColorCoefPage.ui" line="858" />
   <source>CT</source>
   <translation>CT</translation>
  </message>
 </context>
 <context>
  <name>GrabConfigWidget</name>
  <message>
   <location filename="../../src/GrabConfigWidget.ui" line="20" />
   <source>Red</source>
   <translation>Merah</translation>
  </message>
  <message>
   <location filename="../../src/GrabConfigWidget.ui" line="27" />
   <source>Blue</source>
   <translation>Biru</translation>
  </message>
  <message>
   <location filename="../../src/GrabConfigWidget.ui" line="34" />
   <source>Green</source>
   <translation>Hijau</translation>
  </message>
  <message>
   <location filename="../../src/GrabConfigWidget.ui" line="41" />
   <source>Area enabled</source>
   <translation>Area aktif</translation>
  </message>
  <message>
   <location filename="../../src/GrabConfigWidget.ui" line="51" />
   <location filename="../../src/GrabConfigWidget.ui" line="64" />
   <location filename="../../src/GrabConfigWidget.ui" line="77" />
   <source>%</source>
   <translation>%</translation>
  </message>
 </context>
 <context>
  <name>LedDeviceLightpack</name>
  <message>
   <location filename="../../src/LedDeviceLightpack.cpp" line="252" />
   <source>read device fail</source>
   <translation>Gagal membaca perangkat</translation>
  </message>
 </context>
 <context>
  <name>LightpackDiscoveryPage</name>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.cpp" line="62" />
   <source>1 Lightpack found</source>
   <translation>Ditemukan 1 Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.cpp" line="64" />
   <source>%0 Lightpacks found</source>
   <translation>Ditemukan %0 Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.cpp" line="66" />
   <source>%0 zones are available</source>
   <translation>Tersedia %0 zona</translation>
  </message>
 </context>
 <context>
  <name>LightpacksDiscoveryPage</name>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="17" />
   <source>Lightpacks discovery</source>
   <translation>Pencarian Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="32" />
   <source>please connect Lightpack or setup another device</source>
   <translation>Sambungkan Lightpack atau atur perangkat lain</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="45" />
   <source>Continue setting up the Lightpacks</source>
   <translation>Lanjutkan pengaturan Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="100" />
   <source>No Lightpacks connected</source>
   <translation>Tidak ada Lightpack terhubung</translation>
  </message>
  <message>
   <location filename="../../src/wizard/LightpackDiscoveryPage.ui" line="110" />
   <source>Setup another device</source>
   <translation>Atur perangkat lain</translation>
  </message>
 </context>
 <context>
  <name>MonitorIdForm</name>
  <message>
   <location filename="../../src/wizard/MonitorIdForm.ui" line="20" />
   <source>MonitorIdForm</source>
   <translation>MonitorIdForm</translation>
  </message>
  <message>
   <location filename="../../src/wizard/MonitorIdForm.ui" line="55" />
   <source>1</source>
   <translation>1</translation>
  </message>
 </context>
 <context>
  <name>MoodLampManager</name>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Static color</source>
   <translation>Warna statis</translation>
  </message>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Color transition</source>
   <translation>Transisi warna</translation>
  </message>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Breathing</source>
   <translation>Bernapas</translation>
  </message>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Rainbow</source>
   <translation>Pelangi</translation>
  </message>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Wave</source>
   <translation>Gelombang</translation>
  </message>
  <message>
   <location filename="../../src/MoodLampManager.cpp" line="209" />
   <location filename="../../src/SettingsWindow.cpp" line="2443" />
   <source>Fire</source>
   <translation>Api</translation>
  </message>
 </context>
 <context>
  <name>RcxWasapiSoundManager</name>
  <message>
   <location filename="../../src/RcxWasapiSoundManager.cpp" line="23" />
   <source>Default speakers (system audio)</source>
   <translation>Speaker default (audio sistem)</translation>
  </message>
  <message>
   <location filename="../../src/RcxWasapiSoundManager.cpp" line="26" />
   <source>Audio output %1</source>
   <translation>Keluaran audio %1</translation>
  </message>
 </context>
 <context>
  <name>SelectDevicePage</name>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="17" />
   <source>Select connected device</source>
   <translation>Pilih perangkat terhubung</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="36" />
   <source>Ardulight (Serial, 255 LEDs)</source>
   <translation>Ardulight (Serial, 255 LEDs)</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="43" />
   <source>Adalight (Serial, 511 LEDs)</source>
   <translation>Adalight (Serial, 511 LEDs)</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="79" />
   <source>DRGB (UDP, 490 LEDs)</source>
   <translation>DRGB (UDP, 490 LEDs)</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="86" />
   <source>Virtual LED device</source>
   <translation>Perangkat LED virtual</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="106" />
   <source>DNRGB (UDP, 1500 LEDs)</source>
   <translation>DNRGB (UDP, 1500 LEDs)</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectDevicePage.ui" line="113" />
   <source>WARLS (UDP, 255 LEDs)</source>
   <translation>WARLS (UDP, 255 LEDs)</translation>
  </message>
 </context>
 <context>
  <name>SelectProfilePage</name>
  <message>
   <location filename="../../src/wizard/SelectProfilePage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectProfilePage.ui" line="17" />
   <source>Choose profile</source>
   <translation>Pilih profil</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectProfilePage.ui" line="82" />
   <source>Profile to modify:</source>
   <translation>Profil yang diubah:</translation>
  </message>
  <message>
   <location filename="../../src/wizard/SelectProfilePage.cpp" line="105" />
   <source>New profile</source>
   <translation>Profil baru</translation>
  </message>
 </context>
 <context>
  <name>SettingsWindow</name>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="108" />
   <location filename="../../src/SettingsWindow.ui" line="229" />
   <source>Mode</source>
   <translation>Mode</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="147" />
   <location filename="../../src/SettingsWindow.ui" line="1976" />
   <source>Profiles</source>
   <translation>Profil</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="162" />
   <location filename="../../src/SettingsWindow.ui" line="2157" />
   <source>Plugins</source>
   <translation>Plugin</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="177" />
   <location filename="../../src/SettingsWindow.ui" line="2461" />
   <source>Expert</source>
   <translation>Lanjutan</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="192" />
   <location filename="../../src/SettingsWindow.ui" line="2818" />
   <source>About</source>
   <translation>Tentang</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="355" />
   <source>Mode:</source>
   <translation>Mode:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="765" />
   <source>Grab frequency:</source>
   <translation>Frekuensi tangkap:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="787" />
   <source>FPS</source>
   <translation>FPS</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="810" />
   <source>Grab interval:</source>
   <translation>Interval tangkap:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="847" />
   <source>ms</source>
   <translation>ms</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="855" />
   <source>Over-brightening:</source>
   <translation>Tambahan kecerahan:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="866" />
   <source>&lt;h4&gt;Over-brightening&lt;/h4&gt; To achieve a higher overall brightness, Prismatik will set the LEDs to maximum even if the grabbed color is not at full brightness.</source>
   <translation>&lt;h4&gt;Tambahan kecerahan&lt;/h4&gt;Naikkan kecerahan LED walau warna layar belum mencapai kecerahan maksimum.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="727" />
   <source>Black bar detection</source>
   <translation>Deteksi pita hitam</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="730" />
   <source>Ignore black letterbox/pillarbox borders and follow the active picture.</source>
   <translation>Abaikan pita hitam atas/bawah atau kiri/kanan dan ikuti tepi gambar aktif.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="489" />
   <source>Apply screen color modifications (F.lux, redshift)</source>
   <translation>Terapkan perubahan warna layar (F.lux, redshift)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="132" />
   <source>Device</source>
   <translation>Perangkat</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="378" />
   <source>Screen grabbing</source>
   <translation>Mengikuti layar</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="383" />
   <source>Mood lamp</source>
   <translation>Lampu suasana</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="388" />
   <source>Sound visualization</source>
   <translation>Visualisasi suara</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="524" />
   <source>Average color on all LEDs</source>
   <translation>Rata-rata warna seluruh LED</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="590" />
   <source>&lt;h4&gt;Color encoding gamma&lt;/h4&gt;

This is the gamma used for encoding the color with the desired &lt;b&gt;color temperature&lt;/b&gt;. Setting to &lt;b&gt;1.0&lt;/b&gt; cancels the effect.
This is the reciprocal of the &lt;b&gt;device gamma&lt;/b&gt; which is the decoding gamma. They cancel each other if set to same value.</source>
   <translation>&lt;h4&gt;Gamma pengkodean warna&lt;/h4&gt;Gamma untuk suhu warna yang dipilih. Nilai 1 menonaktifkan efek; nilainya berkebalikan dengan gamma perangkat.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="636" />
   <source>&lt;h4&gt;Color temperature &amp;amp; gamma&lt;/h4&gt;

Internally emulates the effects of f.lux, redshift, Night Light, Night Shift...</source>
   <translation>&lt;h4&gt;Suhu warna dan gamma&lt;/h4&gt;Meniru perubahan suhu warna layar seperti f.lux, redshift, Night Light, dan Night Shift.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="641" />
   <source>Apply color temperature and gamma</source>
   <translation>Terapkan suhu warna dan gamma</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="688" />
   <source>Grab widget adjustment</source>
   <translation>Pengaturan area tangkap</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="694" />
   <source>Hidden</source>
   <translation>Tersembunyi</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="704" />
   <source>Colored</source>
   <translation>Berwarna</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="714" />
   <source>All white</source>
   <translation>Semua putih</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="984" />
   <location filename="../../src/SettingsWindow.ui" line="1093" />
   <source>Change color with rate:</source>
   <translation>Ganti warna dengan kecepatan:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="997" />
   <location filename="../../src/SettingsWindow.ui" line="1108" />
   <source>Slow</source>
   <translation>Lambat</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1013" />
   <location filename="../../src/SettingsWindow.ui" line="1142" />
   <source>Fast</source>
   <translation>Cepat</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1194" />
   <source>Sound device:</source>
   <translation>Perangkat audio:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1207" />
   <source>By default, on macOS this feature is limited to input devices (mic, line-in...), a third party software (such as Soundflower etc) is needed to redirect desktop sound into a virtual input that can be used here. The device has to support Linear PCM, 44100Hz (or 32000, 48000) sample rate and 16 (or 24, 32) bits per channel.</source>
   <translation>Pada macOS, input audio memerlukan perangkat PCM yang sesuai. Pada RCX Windows, audio sistem ditangkap langsung melalui WASAPI.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1040" />
   <source>Animate colors from</source>
   <translation>Animasi warna dari</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1066" />
   <source>to</source>
   <translation>ke</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1225" />
   <source>Please note: The sound visualizer works best with low smoothness settings (20 and below, 10 recommended)</source>
   <translation>Visualisasi suara paling baik dengan penghalusan rendah (maksimal 20, disarankan 10)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="233" />
   <source>Eye care settings</source>
   <translation>Pengaturan kenyamanan mata</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="239" />
   <source>Dead-zone</source>
   <translation>Zona mati</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="249" />
   <source>Scene luminosity threshold:</source>
   <translation>Ambang kecerahan adegan:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="259" />
   <source>Luminosity threshold is used for:</source>
   <translation>Ambang kecerahan digunakan untuk:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="269" />
   <source>Minimum luminosity level</source>
   <translation>Kecerahan minimum</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="336" />
   <source>&lt;h4&gt;Scene luminosity threshold&lt;/h4&gt; It works in two ways: You can either use &lt;b&gt;minimum luminosity level&lt;/b&gt; for soft and gentle light in dark scenes or you can use &lt;b&gt;dead-zone&lt;/b&gt; luminosity grabbing which ignores small non-black objects on black backgrounds and turns lights OFF in dark scenes. This is eye-saving vs. eye-killing options which works mutually. We &lt;b&gt;recommend&lt;/b&gt; to use threshold for minimum luminosity level.</source>
   <translation>&lt;h4&gt;Ambang kecerahan adegan&lt;/h4&gt;Mode minimum menjaga cahaya lembut pada adegan gelap. Zona mati mengabaikan detail kecil dan mematikan LED pada adegan gelap. RCX memakai ambang 0% tetap.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="460" />
   <location filename="../../src/SettingsWindow.ui" line="1423" />
   <source>%</source>
   <translation>%</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1915" />
   <source>Run configuration wizard</source>
   <translation>Setting Ulang</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1928" />
   <source>Keep lights ON after exit</source>
   <translation>Tetap nyala setelah aplikasi ditutup</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1935" />
   <source>Keep lights ON after display sleep</source>
   <translation>Tetap nyala setelah layar tidur</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1942" />
   <source>Keep lights ON after lock computer</source>
   <translation>Tetap nyala saat komputer dikunci</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1949" />
   <source>Keep lights ON after system suspend</source>
   <translation>Tetap nyala saat komputer tidur</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1322" />
   <source>Brightness cap:</source>
   <translation>Batas kecerahan:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1291" />
   <location filename="../../src/SettingsWindow.cpp" line="2437" />
   <source>Settings</source>
   <translation>Pengaturan</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="2436" />
   <source>Follow screen</source>
   <translation>Mengikuti Layar</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="2436" />
   <source>Color &amp; Effects</source>
   <translation>Warna &amp; Efek</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="2436" />
   <source>Follow sound</source>
   <translation>Mengikuti Suara</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="402" />
   <location filename="../../src/SettingsWindow.cpp" line="2437" />
   <source>Brightness</source>
   <translation>Kecerahan</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="910" />
   <location filename="../../src/SettingsWindow.ui" line="1028" />
   <source>Effect</source>
   <translation>Efek</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="920" />
   <source>Color</source>
   <translation>Warna</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="937" />
   <source>Speed</source>
   <translation>Kecepatan</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="979" />
   <source>Color:</source>
   <translation>Warna:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1022" />
   <source>Audio response</source>
   <translation>Respons suara</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1022" />
   <source>All sound</source>
   <translation>Seluruh suara</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1022" />
   <source>Bass beats only</source>
   <translation>Hanya beat bass</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1022" />
   <source>Sensitivity</source>
   <translation>Sensitivitas</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1154" />
   <source>Start from bottom center</source>
   <translation>Mulai dari tengah bawah</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1164" />
   <source>Effect start position (LED)</source>
   <translation>Posisi awal efek (LED)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1333" />
   <source>&lt;h4&gt;Gamma correction&lt;/h4&gt; It controls the level of saturation. The effect is clearly detectable in a video in screen grabbing mode&lt;br/&gt;Recommended value: 2.00</source>
   <translation>&lt;h4&gt;Koreksi gamma&lt;/h4&gt;Atur saturasi keluaran. Nilai default 2,00.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1362" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-weight:600;"&gt;Brightness Cap&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lowers the brightness limit of LEDs (as opposed to overall brightness). Can be used to limit the power draw and the heat output. Defaults to 100% (no limit).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Batas kecerahan maksimum LED. RCX selalu memakai 100% tanpa batas tambahan.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1443" />
   <source>Gamma correction:</source>
   <translation>Koreksi gamma:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1498" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;h4 style=" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"&gt;&lt;span style=" font-size:medium; font-weight:600;"&gt;Dithering&lt;/span&gt;&lt;/h4&gt;&lt;p&gt;Increases color accuracy with some devices, but may introduce flickering.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Dithering meningkatkan akurasi warna pada perangkat tertentu tetapi dapat menimbulkan kedipan.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1501" />
   <source>Enable Dithering</source>
   <translation>Aktifkan dithering</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1537" />
   <source>Lightpack</source>
   <translation>Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1555" />
   <source>Smoothness:</source>
   <translation>Penghalusan:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1562" />
   <source>&lt;h4&gt;Color depth&lt;/h4&gt; Number of colors per channel, one RGB LED uses 3 channels (value in power of 3).</source>
   <translation>&lt;h4&gt;Kedalaman warna&lt;/h4&gt;Jumlah warna per kanal RGB.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1590" />
   <source>Color depth (Lightpack 5 and below):</source>
   <translation>Kedalaman warna (Lightpack 5 atau lebih lama):</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1597" />
   <source>&lt;h4&gt;Smoothness&lt;/h4&gt; It defines how many steps will be color changed in</source>
   <translation>&lt;h4&gt;Penghalusan&lt;/h4&gt;Jumlah langkah perubahan warna.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1673" />
   <source>Disable USB Power LED</source>
   <translation>Matikan LED daya USB</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1680" />
   <source>&lt;h4&gt;Refresh delay&lt;/h4&gt; This setting’s values are inversely proportional to the PWM’s frequency. It's affects to performance.</source>
   <translation>&lt;h4&gt;Jeda refresh&lt;/h4&gt;Berbanding terbalik dengan frekuensi PWM dan memengaruhi performa.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1816" />
   <source>Refresh delay (Lightpack 5 and below):</source>
   <translation>Jeda refresh (Lightpack 5 atau lebih lama):</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1830" />
   <source>Virtual</source>
   <translation>Virtual</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1874" />
   <source>Language :</source>
   <translation>Bahasa :</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1985" />
   <source>Profile</source>
   <translation>Profil</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2012" />
   <source>Add new profile</source>
   <translation>Tambah profil baru</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2038" />
   <source>Reset current profile to defaults</source>
   <translation>Reset profil ke default</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2064" />
   <source>Delete profile</source>
   <translation>Hapus profil</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2089" />
   <source>Open in text editor</source>
   <translation>Buka di editor teks</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2114" />
   <source>User interface</source>
   <translation>Antarmuka</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2189" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:medium; font-weight:600;"&gt;Plugins&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Here you can manage your plugins which are stored in you profile folder. Check each plugin's documentation for requirements and settings. Plugins work in priority of order — first plugin in the list has the highest priority.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Kelola ekstensi di folder profil. Plugin dijalankan berdasarkan urutan prioritas; yang paling atas memiliki prioritas tertinggi. Fitur RCX tidak memerlukan plugin.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2195" />
   <source>All plugins:</source>
   <translation>Semua plugin:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2272" />
   <source>Increase priority</source>
   <translation>Naikkan prioritas</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2286" />
   <source>Decrease priority</source>
   <translation>Turunkan prioritas</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2300" />
   <source>Reload plugins</source>
   <translation>Muat ulang plugin</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2322" />
   <source>Info</source>
   <translation>Informasi</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2346" />
   <source>Author:</source>
   <translation>Penulis:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2388" />
   <source>Name:</source>
   <translation>Nama:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2430" />
   <source>Version:</source>
   <translation>Versi:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2470" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This tab is used for experimental and unstable features. Any tuning with these controls may cause inevitable plane crash, miscarriage or nuclear disaster. Use it at your own risk.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Pengaturan lanjutan untuk sumber tangkap, API, dan log.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2492" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enables TCP socket server.&lt;/p&gt;&lt;p&gt;You can connect via &amp;quot;telnet &amp;lt;ip&amp;gt; &amp;lt;port&amp;gt;&amp;quot; for example and manually execute available commands.&lt;/p&gt;&lt;p&gt;Default: %1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Aktifkan server TCP untuk perintah eksternal. Default: %1.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2498" />
   <source>Enable server (API via sockets)</source>
   <translation>Aktifkan server (API socket)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2510" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When enabled, you can connect ONLY from the same computer through 127.0.0.1/localhost address.&lt;/p&gt;&lt;p&gt;Disable this if you want to connect from anywhere else.&lt;/p&gt;&lt;p&gt;Default: %1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Jika aktif, hanya komputer ini (127.0.0.1/localhost) yang dapat terhubung. Default: %1.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2513" />
   <source>Listen only on local interface (127.0.0.1)</source>
   <translation>Hanya koneksi lokal (127.0.0.1)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2526" />
   <location filename="../../src/SettingsWindow.ui" line="2533" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;TCP port to listen.&lt;/p&gt;&lt;p&gt;Default: %1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Port TCP server. Default: %1.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2539" />
   <source>Port:</source>
   <translation>Port:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2549" />
   <source>Generate a random one</source>
   <translation>Buat secara acak</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2552" />
   <source>Generate</source>
   <translation>Buat</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2571" />
   <location filename="../../src/SettingsWindow.ui" line="2587" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The API Key all the clients should provide to authenticate. Could be any custom string (%1 character limit). &lt;/p&gt;&lt;p&gt;Default: %2&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Kunci untuk autentikasi klien API, maksimum %1 karakter. Default: %2.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2593" />
   <source>Key (authorization disabled if empty):</source>
   <translation>Kunci (kosong = tanpa autentikasi):</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1894" />
   <location filename="../../src/SettingsWindow.ui" line="2612" />
   <source>Capture source</source>
   <translation>Sumber tangkap</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2636" />
   <source>Mac AV (Full screen)</source>
   <translation>Mac AV (layar penuh)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="1901" />
   <source>Win8 Desktop Duplication</source>
   <translation>Windows Desktop Duplication</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2677" />
   <source>Enable DX hooking</source>
   <translation>Aktifkan hook DX</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2709" />
   <source>also hook D3D9 (high performance impact)</source>
   <translation>Juga hook D3D9 (berpengaruh besar pada performa)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2723" />
   <source>Logging level:</source>
   <translation>Tingkat log:</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2733" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Log verbosity: %1-%2 where %1 = no logs.&lt;/p&gt;&lt;p&gt;After enabling logs you need to restart the program.&lt;/p&gt;&lt;p&gt;When enabled you can use the &lt;img src=":/buttons/arrow_right_dark_24px.png" width="12"&gt; button to open the log directory.&lt;/p&gt;&lt;p&gt;Default: %3&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Tingkat log %1–%2; %1 = tanpa log. Setelah mengaktifkan log, mulai ulang aplikasi. Default: %3.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2743" />
   <location filename="../../src/SettingsWindow.ui" line="2746" />
   <source>open Log folder</source>
   <translation>Buka folder log</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2749" />
   <source>...</source>
   <translation>...</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2775" />
   <source>Ping Lightpack device every second</source>
   <translation>Periksa Lightpack setiap detik</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2782" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When disabled every frame will be sent to the device. This is recommended for devices with inactivity timers built into firmwares (some custom Adalight sketches for example) or configured via Prismatik (UDP devices with a &amp;lt; 255 timeout value).&lt;/p&gt;&lt;p&gt;When enabled every new frame will be compared with the previous one, and will be sent only if differences are detected (can be useful in low bandwidth situations).&lt;/p&gt;&lt;p&gt;Default: %1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Jika nonaktif, setiap frame dikirim ke perangkat, cocok untuk firmware dengan timer. Jika aktif, hanya frame yang berubah yang dikirim. Default: %1.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2785" />
   <source>Send data only if colors changed</source>
   <translation>Kirim data hanya saat warna berubah</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="3074" />
   <location filename="../../src/SettingsWindow.cpp" line="215" />
   <source>Credits and licenses</source>
   <translation>Kredit dan lisensi</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2866" />
   <source>&lt;h2&gt;Prismatik (unofficial fork)&lt;/h2&gt;</source>
   <translation>&lt;h2&gt;RCX Prismatik (fork tidak resmi)&lt;/h2&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2898" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The &lt;span style=" font-weight:600;"&gt;Woodenshark&lt;/span&gt; team created this software with &lt;span style=" font-weight:600;"&gt;Lightpack&lt;/span&gt; — content-appropriate ambient lighting system with USB interface&lt;br/&gt;&lt;span style=" font-weight:600;"&gt;This is an unofficial fork of the open source project that is not affiliated with Woodenshark or Lightpack&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Prismatik dibuat oleh tim Woodenshark dan penulis upstream. RCX adalah fork tidak resmi, tidak berafiliasi dengan Woodenshark atau Lightpack.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2938" />
   <source>Check for updates on startup</source>
   <translation>Periksa pembaruan saat aplikasi dibuka</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2946" />
   <source>Install updates automatically</source>
   <translation>Pasang pembaruan otomatis</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="2985" />
   <source>This program is distributed «as is». Its source code is under the &lt;a href="http://www.gnu.org/licenses/gpl.html"&gt;&lt;span style=" text-decoration: underline; color:#0000ff;"&gt;GPL license&lt;/span&gt;&lt;/a&gt;. No warranty of any kind is expressed or implied. The authors will not be liable for data loss, damages, loss of profits or any other kind of loss while using or misusing this software. All content, such as icons, plugins, bitmaps etc. is under &lt;a href="http://creativecommons.org/licenses/by-sa/3.0/"&gt;&lt;span style=" text-decoration: underline; color:#0000ff;"&gt;CC-BY-SA&lt;/span&gt;&lt;/a&gt; if otherwise is not noticed. &lt;br/&gt;&lt;br/&gt;This software build with the &lt;a href="http://qt-project.org/"&gt;&lt;span style=" text-decoration: underline; color:#0000ff;"&gt;Qt&lt;/span&gt;&lt;/a&gt; cross-platform framework, the &lt;a href="http://www.openssl.org/"&gt;&lt;span style=" text-decoration: underline; color:#0000ff;"&gt;OpenSSL Toolkit&lt;/span&gt;&lt;/a&gt; and &lt;a href="http://somerandomdude.com/work/iconic/"&gt;&lt;span style=" text-decoration: underline; color:#0000ff;"&gt;«Iconic»&lt;/span&gt;&lt;/a&gt; icon set by P.J. Onori as third-party licensed products.</source>
   <translation>&lt;p&gt;Fork RCX berdasarkan psieg/Lightpack dan penulis upstream. Source tersedia di bawah &lt;a href="https://www.gnu.org/licenses/gpl.html"&gt;GPL&lt;/a&gt;, tanpa jaminan. Copyright dan lisensi asset upstream dipertahankan. Qt dan aset pihak ketiga tunduk pada lisensi masing-masing; lihat paket source dan licenses yang disertakan.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.ui" line="3015" />
   <source>qrc:/text/cast.html</source>
   <translation>qrc:/text/cast.html</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="152" />
   <location filename="../../src/SettingsWindow.cpp" line="2445" />
   <source>Re-Configure</source>
   <translation>Setting Ulang</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="173" />
   <source>Controller %1 / %2 / RCX-%3: %4</source>
   <translation>Controller %1 / %2 / RCX-%3: %4</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="173" />
   <source>Connected</source>
   <translation>Terhubung</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="173" />
   <source>Disconnected — waiting for RCX controller</source>
   <translation>Terputus — menunggu controller RCX</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="230" />
   <location filename="../../src/SettingsWindow.cpp" line="233" />
   <location filename="../../src/SettingsWindow.cpp" line="250" />
   <source>ON</source>
   <translation>NYALA</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="230" />
   <location filename="../../src/SettingsWindow.cpp" line="233" />
   <location filename="../../src/SettingsWindow.cpp" line="250" />
   <source>OFF</source>
   <translation>MATI</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="240" />
   <source>none</source>
   <translation>tidak ada</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="439" />
   <location filename="../../src/SettingsWindow.cpp" line="1816" />
   <source>RCX Prismatik: %1</source>
   <translation>RCX Prismatik: %1</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="447" />
   <location filename="../../src/SettingsWindow.cpp" line="1854" />
   <source>System default</source>
   <translation>Ikuti sistem</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="489" />
   <location filename="../../src/SettingsWindow.cpp" line="1728" />
   <source>Profile: %1</source>
   <translation>Profil: %1</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="491" />
   <source>Device: %1</source>
   <translation>Perangkat: %1</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="492" />
   <source>FPS: %1</source>
   <translation>FPS: %1</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="592" />
   <source>Prismatik was updated</source>
   <translation>Prismatik telah diperbarui</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="592" />
   <source>Successfully updated to version %1.</source>
   <translation>Berhasil diperbarui ke versi %1.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="596" />
   <source>Prismatik automatic update failed</source>
   <translation>Pembaruan otomatis Prismatik gagal</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="597" />
   <source>There was a problem when trying to automatically update Prismatik to the latest version.
</source>
   <translation>Pembaruan otomatis Prismatik gagal.
</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="598" />
   <source>You are still on version %1.
</source>
   <translation>Versi saat ini tetap %1.
</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="599" />
   <source>Installing updates automatically was disabled.</source>
   <translation>Pembaruan otomatis dinonaktifkan.</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="687" />
   <source> (restart the program first)</source>
   <translation> (mulai ulang aplikasi dahulu)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="689" />
   <location filename="../../src/SettingsWindow.cpp" line="2044" />
   <source> (enable logs first and restart the program)</source>
   <translation> (aktifkan log lalu mulai ulang aplikasi)</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="845" />
   <location filename="../../src/SettingsWindow.cpp" line="882" />
   <source>Turn lights OFF</source>
   <translation>Matikan LED</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="874" />
   <source>Turn lights ON</source>
   <translation>Nyalakan LED</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="1199" />
   <source>update firmware</source>
   <translation>perbarui firmware</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="1258" />
   <source>&lt;html&gt;&lt;body&gt;&lt;p&gt;Your frame rate reached &lt;b&gt;%1 FPS&lt;/b&gt;, your baud rate of &lt;b&gt;%2&lt;/b&gt; might be too low for the amount of LEDs (%3).&lt;/p&gt;&lt;p&gt;You might experience lag or visual artifacts with your LEDs.&lt;/p&gt;&lt;p&gt;Lower your target framerate to &lt;b&gt;under %4 FPS&lt;/b&gt; or increase your baud rate to &lt;b&gt;above %5&lt;/b&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Frame rate %1 FPS mungkin melebihi baud %2 untuk %3 LED. Turunkan ke bawah %4 FPS atau naikkan baud di atas %5.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="1275" />
   <source>FPS: </source>
   <translation>FPS: </translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="1749" />
   <source>New profile</source>
   <translation>Profil baru</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="2166" />
   <source>&lt;!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd"&gt; &lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;style type="text/css"&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;"&gt; &lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"&gt;software &lt;span style=" font-size:8pt; font-weight:600;"&gt;%1&lt;/span&gt;&lt;span style=" font-size:8pt;"&gt; (rev &lt;/span&gt;&lt;a href="https://github.com/psieg/Lightpack/commit/%2"&gt;&lt;span style=" font-size:8pt; text-decoration: underline; color:#0000ff;"&gt;%2&lt;/span&gt;&lt;/a&gt;&lt;span style=" font-size:8pt;"&gt;, Qt %4), firmware &lt;b&gt;%3&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd"&gt; &lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;style type="text/css"&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;"&gt; &lt;p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"&gt;software &lt;span style=" font-size:8pt; font-weight:600;"&gt;%1&lt;/span&gt;&lt;span style=" font-size:8pt;"&gt; (rev &lt;/span&gt;&lt;a href="https://github.com/psieg/Lightpack/commit/%2"&gt;&lt;span style=" font-size:8pt; text-decoration: underline; color:#0000ff;"&gt;%2&lt;/span&gt;&lt;/a&gt;&lt;span style=" font-size:8pt;"&gt;, Qt %4), firmware &lt;b&gt;%3&lt;/b&gt;&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
  </message>
  <message>
   <location filename="../../src/SettingsWindow.cpp" line="2183" />
   <location filename="../../src/SettingsWindow.cpp" line="2448" />
   <source>Version %1</source>
   <translation>Versi %1</translation>
  </message>
 </context>
 <context>
  <name>SysTrayIcon</name>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="96" />
   <source>Prismatik</source>
   <translation>Prismatik</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="96" />
   <source>Application already running</source>
   <translation>Aplikasi sudah berjalan</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="99" />
   <source>Lightpack firmware update</source>
   <translation>Pembaruan firmware Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="99" />
   <source>Click on this message to open lightpack downloads page</source>
   <translation>Klik pesan ini untuk membuka halaman unduhan Lightpack</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="126" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="324" />
   <source>&amp;Turn on</source>
   <translation>&amp;Nyalakan LED</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="127" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="328" />
   <source>&amp;Turn off</source>
   <translation>&amp;Matikan LED</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="128" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="337" />
   <source>&amp;Settings</source>
   <translation>&amp;Pengaturan</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="129" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="341" />
   <source>&amp;Quit</source>
   <translation>&amp;Keluar</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="130" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="333" />
   <source>&amp;Profiles</source>
   <translation>&amp;Profil</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="137" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="166" />
   <source>Enabled profile: %1</source>
   <translation>Profil aktif: %1</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="140" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="190" />
   <source>Disabled</source>
   <translation>Nonaktif</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="143" />
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="197" />
   <source>Error with connection device, verbose in logs</source>
   <translation>Koneksi perangkat gagal; lihat log</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="173" />
   <source>Device locked via API</source>
   <translation>Perangkat dikunci melalui API</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="177" />
   <source>Device locked via Plugin</source>
   <translation>Perangkat dikunci melalui plugin</translation>
  </message>
  <message>
   <location filename="../../src/systrayicon/SysTrayIcon.cpp" line="183" />
   <source>API colors persisted</source>
   <translation>Warna API dipertahankan</translation>
  </message>
 </context>
 <context>
  <name>WindowsSoundManager</name>
  <message>
   <location filename="../../src/WindowsSoundManager.cpp" line="78" />
   <source> (loopback)</source>
   <translation> (audio sistem)</translation>
  </message>
 </context>
 <context>
  <name>Wizard</name>
  <message>
   <location filename="../../src/wizard/Wizard.ui" line="14" />
   <source>Wizard</source>
   <translation>Panduan</translation>
  </message>
 </context>
 <context>
  <name>ZonePlacementPage</name>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="14" />
   <source>WizardPage</source>
   <translation>WizardPage</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="17" />
   <source>Zone placement</source>
   <translation>Penempatan zona</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="23" />
   <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;table border="0" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;" cellspacing="0" cellpadding="0"&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;You can disable some zones by using the gear button of the zone.&lt;br/&gt;
You'll be able to re-adjust each zone individually later:&lt;br/&gt;
Mode tab &gt; Screen grabbing mode &gt; Grab widget adjustment&lt;/p&gt;&lt;/td&gt;&lt;td style=" padding-left:2;"&gt;&lt;p&gt;&lt;img src=":/buttons/settings_24px.png" width="16"/&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
   <translation>&lt;p&gt;Zona dapat dinonaktifkan dan diatur melalui tombol pengaturan pada area tangkap.&lt;/p&gt;</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="36" />
   <source>Andromeda</source>
   <translation>Andromeda</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="43" />
   <source>Cassiopeia</source>
   <translation>Cassiopeia</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="50" />
   <source>Pegasus</source>
   <translation>Pegasus</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="57" />
   <source>Number of LEDs:</source>
   <translation>Jumlah LED:</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="85" />
   <source>Sides</source>
   <translation>Sisi</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="95" />
   <source>Bottom margin</source>
   <translation>Margin bawah</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="105" />
   <source>Side margin</source>
   <translation>Margin samping</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="115" />
   <source>Bottom</source>
   <translation>Bawah</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="125" />
   <source>Top margin</source>
   <translation>Margin atas</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="135" />
   <source>invert order</source>
   <translation>Balik urutan</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="155" />
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="208" />
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="237" />
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="266" />
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="289" />
   <source>%</source>
   <translation>%</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="171" />
   <source>Apply</source>
   <translation>Terapkan</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="178" />
   <source>skip corners</source>
   <translation>Lewati sudut</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="195" />
   <source>Top</source>
   <translation>Atas</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="253" />
   <source>Bottom gap</source>
   <translation>Celah bawah</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="305" />
   <source>Thickness</source>
   <translation>Ketebalan</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="315" />
   <source>Start offset</source>
   <translation>Offset awal</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="325" />
   <source>Clear Display</source>
   <translation>Bersihkan layar</translation>
  </message>
  <message>
   <location filename="../../src/wizard/ZonePlacementPage.ui" line="339" />
   <source>Starting LED for this display</source>
   <translation>LED awal untuk layar ini</translation>
  </message>
 </context>
</TS>