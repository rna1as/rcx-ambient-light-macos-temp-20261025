QT += core gui widgets network serialport testlib
CONFIG += console c++17 testcase
TEMPLATE = app
TARGET = rcx-tests
INCLUDEPATH += ../src ../math/include ..
SOURCES += tst_rcx.cpp ../src/LedDeviceAdalight.cpp ../src/LedDeviceRcx.cpp ../src/AbstractLedDevice.cpp ../src/Settings.cpp
HEADERS += ../src/LedDeviceAdalight.hpp ../src/LedDeviceRcx.hpp ../src/AbstractLedDevice.hpp ../src/Settings.hpp
LIBS += -L../lib -lprismatik-math
DEFINES += NO_OPENSSL SOUNDVIZ_SUPPORT
INCLUDEPATH += ../grab/include
SOURCES += ../src/RcxWasapiSoundManager.cpp ../src/SoundManagerBase.cpp ../src/SoundVisualizer.cpp ../src/LiquidColorGenerator.cpp
HEADERS += ../src/RcxWasapiSoundManager.hpp ../src/SoundManagerBase.hpp ../src/SoundVisualizer.hpp ../src/LiquidColorGenerator.hpp
HEADERS += ../src/RcxAudioLevel.hpp
LIBS += -lole32 -luuid -lwinmm
SOURCES += ../../RCXAuth/monocypher/monocypher.c ../../RCXAuth/monocypher/monocypher-ed25519.c
LIBS += -lbcrypt

HEADERS += ../src/RcxAudioVolumeMonitor.hpp
