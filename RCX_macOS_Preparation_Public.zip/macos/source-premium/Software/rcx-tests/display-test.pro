QT += widgets
CONFIG += c++17 console
TEMPLATE = app
TARGET = rcx-display-test
SOURCES += display-test.cpp
