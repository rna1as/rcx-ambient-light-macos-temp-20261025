// Temporary display stimulus for capture verification; no controller setting writes.
#include <QApplication>
#include <QScreen>
#include <QWidget>
#include <QPalette>
#include <QTimer>
#include <QDebug>
#include <QPainter>
class Letterbox : public QWidget {
protected:
 void paintEvent(QPaintEvent *) override {QPainter p(this);p.fillRect(rect(),Qt::black);p.fillRect(QRect(0,height()/5,width(),height()*3/5),Qt::red);}
};
int main(int argc, char **argv) {
 QApplication app(argc,argv);
 const QColor color(argc>1 ? argv[1] : "black");
 QList<QWidget *> windows;
 for (auto *screen : app.screens()) {
  QWidget *window = QString(argc>1?argv[1]:"")=="letterbox" ? static_cast<QWidget*>(new Letterbox) : new QWidget;
  window->setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Tool);
  window->setGeometry(screen->geometry());
  QPalette palette;palette.setColor(QPalette::Window,color);window->setPalette(palette);
  window->setAutoFillBackground(true);window->show();windows<<window;
 }
 QTimer::singleShot(8000,&app,&QApplication::quit);
 return app.exec();
}
