#include <QApplication>
#include <QTranslator>
#include <QTimer>
#include <QDir>
#include <QTemporaryDir>
#include <QSignalBlocker>
#include <QTabBar>
#include <QFile>
#include "Settings.hpp"
#include "RcxEffects.hpp"
#include "ui_SettingsWindow.h"
using SettingsScope::Settings;
unsigned g_debugLevel=0;
int main(int argc,char **argv){QApplication app(argc,argv);auto trace=[](const char *s){QFile f("budget-proof-trace.txt");f.open(QIODevice::Append);f.write(s);f.write("\n");f.close();};trace("app");QTemporaryDir config;Settings::Initialize(config.path(),false);trace("settings");QTranslator translator;translator.load(":/translations/id_ID.qm");app.installTranslator(&translator);QMainWindow window;Ui::SettingsWindow form;auto *ui=&form;trace("before setup");ui->setupUi(&window);trace("after setup");
QStringList names{"Static color","Color transition","Breathing","Rainbow","Wave","Fire"};for(int i=0;i<names.size();++i)ui->comboBox_MoodLampLamp->addItem(QCoreApplication::translate("MoodLampManager",names[i].toUtf8().constData()),i);
ui->comboBox_SoundVizVisualizer->addItem("Twin Peaks");ui->comboBox_Language->addItem("Bahasa Indonesia");ui->comboBox_Language->addItem("English");ui->spinBox_DeviceBrightness->setSuffix("%");
ui->pushButton_EnableDisableDevice->setText(QCoreApplication::translate("SettingsWindow","Turn lights OFF"));
auto apply=[&](){trace("apply");

trace("line 1");    ui->listWidget->setFixedWidth(114);
trace("line 2");    ui->budgetRow_page_32->setSpacing(6);ui->budgetRow_page_32->setAlignment(Qt::AlignLeft);
trace("line 3");    ui->radioButton_SoundVizConstantMode->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
trace("line 4");    ui->label_10->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
trace("line 5");    ui->pushButton_SelectColorSoundVizMin->setFixedSize(26,24);ui->pushButton_SelectColorSoundVizMax->setFixedSize(26,24);
trace("line 6");    ui->pushButton_SelectColorMoodLamp->setFixedSize(48,24);
trace("line 7");    if(ui->listWidget->count()>4){ui->listWidget->item(3)->setHidden(true);ui->listWidget->item(4)->setHidden(true);}
trace("line 8");    ui->comboBox_LightpackModes->setItemText(0,QCoreApplication::translate("SettingsWindow","Follow screen"));ui->comboBox_LightpackModes->setItemText(1,QCoreApplication::translate("SettingsWindow","Color & Effects"));ui->comboBox_LightpackModes->setItemText(2,QCoreApplication::translate("SettingsWindow","Follow sound"));
trace("line 9");    ui->label_5->setText(QCoreApplication::translate("SettingsWindow","Brightness"));if(auto *settingsItem=ui->listWidget->item(1))settingsItem->setText(QCoreApplication::translate("SettingsWindow","Settings"));
trace("line 10");    ui->horizontalSlider_DeviceBrightness->show();ui->spinBox_DeviceBrightness->show();ui->label_5->show();
trace("line 11");    if(Settings::isProfileLoaded()){QSettings profile(Settings::getCurrentProfilePath(),QSettings::IniFormat);QSignalBlocker a(ui->checkBox_RcxSoundOffsetAuto),b(ui->spinBox_RcxSoundOffset);bool automatic=profile.value("RCX/SoundOffsetAuto",true).toBool();int count=Settings::getNumberOfLeds(Settings::getConnectedDevice());QList<QRect> zones;for(int i=0;i<count;++i)zones.append(QRect(Settings::getLedPosition(i),Settings::getLedSize(i)));int offset=automatic?rcxBottomCenterOffset(zones):profile.value("RCX/SoundStartOffset",0).toInt();ui->checkBox_RcxSoundOffsetAuto->setChecked(automatic);ui->spinBox_RcxSoundOffset->setMaximum(qMax(1,count));ui->spinBox_RcxSoundOffset->setValue(offset+1);ui->spinBox_RcxSoundOffset->setEnabled(!automatic);}
trace("line 12");    {QSettings c(Settings::getCurrentProfilePath(),QSettings::IniFormat);QSignalBlocker a(ui->comboBox_RcxAudioBand),b(ui->slider_RcxAudioSensitivity);ui->comboBox_RcxAudioBand->setCurrentIndex(c.value("RCX/AudioBassOnly",false).toBool()?1:0);ui->slider_RcxAudioSensitivity->setValue(c.value("RCX/AudioSensitivity",100).toInt());}
trace("line 13");    int effect=Settings::getMoodLampLamp();bool hasColor=effect==0||effect==2||effect==4;ui->label_RcxMoodColor->setVisible(hasColor);ui->pushButton_SelectColorMoodLamp->setVisible(hasColor);ui->label_RcxMoodSpeed->setVisible(effect!=0);ui->horizontalSlider_MoodLampSpeed->setVisible(effect!=0);ui->horizontalSlider_MoodLampSpeed->setEnabled(true);

trace("line 15");    const QStringList effectNames{QT_TRANSLATE_NOOP("MoodLampManager","Static color"),QT_TRANSLATE_NOOP("MoodLampManager","Color transition"),QT_TRANSLATE_NOOP("MoodLampManager","Breathing"),QT_TRANSLATE_NOOP("MoodLampManager","Rainbow"),QT_TRANSLATE_NOOP("MoodLampManager","Wave"),QT_TRANSLATE_NOOP("MoodLampManager","Fire")};
trace("line 16");    for(int i=0;i<ui->comboBox_MoodLampLamp->count();++i){int id=ui->comboBox_MoodLampLamp->itemData(i).toInt();if(id>=0&&id<effectNames.size())ui->comboBox_MoodLampLamp->setItemText(i,QCoreApplication::translate("MoodLampManager",effectNames[id].toUtf8().constData()));}
trace("line 17");    ui->pbRunConfigurationWizard->setText(QCoreApplication::translate("SettingsWindow","Re-Configure"));
trace("line 18");    ui->label_RcxAboutLogo->setPixmap(QPixmap(":/icons/rcx-about.png").scaled(144,144,Qt::KeepAspectRatio,Qt::SmoothTransformation));
trace("line 19");    ui->label_RcxAboutLogo->setMinimumHeight(160);
trace("line 20");    ui->labelVersions->setText(QCoreApplication::translate("SettingsWindow","Version %1").arg(QStringLiteral("2.4.0 Budget")));
trace("line 21");    ui->labelVersions->setMinimumHeight(24);
trace("line 22");    QSettings c(Settings::getMainConfigPath(),QSettings::IniFormat);
trace("line 23");    ui->checkBox_RcxBlackBars->setChecked(c.value("RCX/BlackBarDetection",true).toBool());
trace("line 24");    for(const auto &name:QStringList{"label_RcxSoundEffect","comboBox_SoundVizVisualizer","checkBox_RcxSoundOffsetAuto","spinBox_RcxSoundOffset","label_RcxSoundOffset","groupBox_3","groupBox_2","groupBox_UserInterface","groupBox","comboBox_SoundVizDevice","label_SoundVizDevice","radioButton_ConstantColorMoodLampMode","radioButton_LiquidColorMoodLampMode","label_GrabFrequency_txt","label_GrabFrequency_value","label_GrabFrequency_txt_fps","label_SlowdownGrab_txt","spinBox_GrabSlowdown","label_SlowdownGrab_txt_ms","label_11","horizontalSlider_GrabOverBrighten","spinBox_GrabOverBrighten","checkBox_GrabIsAvgColors","checkBox_GrabApplyBlueLightReduction","checkBox_GrabApplyColorTemperature","horizontalSlider_GrabColorTemperature","spinBox_GrabColorTemperature","horizontalSlider_GrabGamma","doubleSpinBox_GrabGamma","pushButton_grabApplyColorTemperatureHelp","pushButton_grabGammaHelp","pushButton_grabOverBrightenHelp","label_7","horizontalSlider_DeviceBrightnessCap","spinBox_DeviceBrightnessCap","label_GammaCorrection","horizontalSlider_GammaCorrection","doubleSpinBox_DeviceGamma","checkBox_EnableDithering","pushButton_BrightnessCapHelp","pushButton_GammaCorrectionHelp","pushButton_DitheringHelp","tabDevices","label","label_2","label_3","label_8","line","label_licenseAndCredits","textBrowser","checkBox_checkForUpdates","checkBox_installUpdates"}) {
trace("line 25");        if(auto *control=window.findChild<QWidget*>(name))control->hide();
    }
trace("applied");};
ui->tabWidget->tabBar()->hide();window.resize(528,714);window.show();QDir dir(argc>1?argv[1]:".");dir.mkpath(".");
for(int mode=0;mode<3;++mode){Settings::setLightpackMode(static_cast<Lightpack::Mode>(mode));Settings::setDeviceBrightness(90-mode*20);ui->comboBox_LightpackModes->setCurrentIndex(mode);ui->stackedWidget_LightpackModes->setCurrentIndex(mode);ui->horizontalSlider_DeviceBrightness->setValue(Settings::getDeviceBrightness());ui->spinBox_DeviceBrightness->setValue(Settings::getDeviceBrightness());ui->tabWidget->setCurrentIndex(0);apply();app.processEvents();window.grab().save(dir.filePath(QString("mode-%1.png").arg(mode)));if(ui->listWidget->item(3)->isHidden()==false)return 2;QRect button=ui->pushButton_EnableDisableDevice->geometry();if(qAbs(button.center().x()-ui->tabSoftwareOptions->rect().center().x())>3)return 3;}
for(int page:{1,5}){ui->tabWidget->setCurrentIndex(page);apply();app.processEvents();window.grab().save(dir.filePath(QString("page-%1.png").arg(page)));}
ui->tabWidget->setCurrentIndex(5);if(ui->pushButton_RcxCredits->geometry().top()<=ui->labelVersions->geometry().bottom())return 4;
if(ui->comboBox_Language->parentWidget()!=ui->tabDeviceOptions||ui->radioButton_GrabDDupl->parentWidget()!=ui->tabDeviceOptions)return 5;
return 0;}
