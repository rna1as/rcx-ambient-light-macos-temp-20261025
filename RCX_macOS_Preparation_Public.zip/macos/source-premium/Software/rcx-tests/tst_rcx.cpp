// RCX tests, GPL-3.0-or-later.
#include <QtTest>
#include "RcxIdentity.hpp"
#include "LedDeviceRcx.hpp"
#include "Settings.hpp"
#include <QTemporaryDir>
#include <QSettings>
#include <QImage>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QTcpSocket>
#include <QFileInfo>
#include <algorithm>
#include <cmath>
#include "RcxBlackBars.hpp"
#include "RcxWasapiSoundManager.hpp"
#include "RcxEffects.hpp"
#include "RcxAudioLevel.hpp"
#include "SoundVisualizer.hpp"
#include <mmsystem.h>
unsigned g_debugLevel = 0;
class CapturedRcx : public LedDeviceRcx {
public:
    CapturedRcx(const QString &dir) : LedDeviceRcx("ABC123", dir) {}
    QByteArray frame;
protected:
    bool writeBuffer(const QByteArray &bytes) override { frame = bytes; return true; }
};
class RcxTests : public QObject {
 Q_OBJECT
 QTemporaryDir m_dir;
private slots:
 void initTestCase(){qRegisterMetaType<QList<QRgb>>("QList<QRgb>");SettingsScope::Settings::Initialize(m_dir.path(),false);}
 void identityContract() {
    const QByteArray line("RCX_AMBILIGHT_V1;FW=1.4.2;ID=BA4C43;SERIAL=RCX-AMB-BA4C43;MODEL=RCX-AMBI-S300;MAX=300;BAUD=921600\r\n");
    QCOMPARE(rcxIdentity(line).value("ID"), QString("BA4C43"));
    QVERIFY(rcxIdentity(line + ";ID=OTHER").isEmpty());
    QVERIFY(rcxIdentity(QByteArray(line).replace("BAUD=921600", "BAUD=115200")).isEmpty());
    QVERIFY(!rcxIdentity(QByteArray(line).replace("MAX=300", "MAX=350")).isEmpty());
    QVERIFY(rcxIdentity(QByteArray(line).replace("MAX=300", "MAX=900")).isEmpty());
    QVERIFY(rcxIdentity(QByteArray(line).replace("ID=BA4C43", "ID=COM6")).isEmpty());
 }
 void framingAndBlack() {
    CapturedRcx device(m_dir.path());
    device.setBrightness(100, false);device.setGamma(1, false);
    device.setBrightnessCap(0,false); // RCX must ignore any requested cap.
    device.setLuminosityThreshold(50, false);device.setMinimumLuminosityThresholdEnabled(true, false);
    device.setColors({qRgb(255,0,0),qRgb(0,0,0)});
    QCOMPARE(device.frame.toHex(), QByteArray("416461000154ff0000000000"));
    QList<QRgb> black;
    for (int i = 0; i < 350; ++i) black << qRgb(0,0,0);
    device.setColors(black);
    QCOMPARE(device.frame.size(), 1056);
    QCOMPARE(device.frame.left(6).toHex(), QByteArray("416461015d09"));
    QCOMPARE(device.frame.mid(6), QByteArray(1050,0));
    black << qRgb(0,0,0);
    device.setColors(black);
    QCOMPARE(device.frame.size(), 1056); // hard 350 LED cap
 }
 void blackBarDetection(){
    QImage image(320,200,QImage::Format_RGB32);image.fill(qRgb(0,0,0));
    for(int y=25;y<175;++y)for(int x=0;x<320;++x)image.setPixel(x,y,qRgb(255,0,0));
    RcxBlackBars detector;QRect active;
    auto pixel=[&](int x,int y){return image.pixel(x,y);};
    for(int i=0;i<8;++i)active=detector.update(320,200,pixel);
    QCOMPARE(active,QRect(0,25,320,150));
    QCOMPARE(RcxBlackBars::remap(QRect(0,180,80,20),QRect(0,0,320,200),active),QRect(0,160,80,15));
    image.fill(qRgb(0,0,0));for(int i=0;i<12;++i)active=detector.update(320,200,pixel);QCOMPARE(active,QRect(0,0,320,200));
    for(int y=0;y<200;++y)for(int x=40;x<280;++x)image.setPixel(x,y,qRgb(0,255,0));
    for(int i=0;i<8;++i)active=detector.update(320,200,pixel);QCOMPARE(active,QRect(40,0,240,200));
    image.fill(qRgb(128,128,128));for(int i=0;i<12;++i)active=detector.update(320,200,pixel);QCOMPARE(active,QRect(0,0,320,200));
 }
 void windowsSystemAudio(){
    RcxWasapiSoundManager sound;sound.setDevice(-1);sound.setLiquidMode(false);sound.setMinColor(Qt::black);sound.setMaxColor(Qt::blue);QSignalSpy output(&sound,&SoundManagerBase::updateLedsColors);sound.start(true);
    const int samples=44100*2;QByteArray pcm;pcm.resize(samples*2);
    for(int i=0;i<samples;++i){qint16 v=qint16(2200*std::sin(2*3.141592653589793*440*i/44100));pcm[i*2]=char(v&255);pcm[i*2+1]=char((v>>8)&255);}
    QByteArray wav("RIFF");auto put32=[&](quint32 v){for(int i=0;i<4;++i)wav.append(char(v>>(8*i)));};auto put16=[&](quint16 v){wav.append(char(v));wav.append(char(v>>8));};
    put32(pcm.size()+36);wav.append("WAVEfmt ");put32(16);put16(1);put16(1);put32(44100);put32(88200);put16(2);put16(16);wav.append("data");put32(pcm.size());wav.append(pcm);
    QString path=m_dir.path()+"/tone.wav";QFile file(path);QVERIFY(file.open(QIODevice::WriteOnly));file.write(wav);file.close();
    QVERIFY(PlaySoundW(reinterpret_cast<LPCWSTR>(path.utf16()),nullptr,SND_FILENAME|SND_ASYNC|SND_NODEFAULT));
    QTRY_VERIFY_WITH_TIMEOUT(*std::max_element(sound.fft(),sound.fft()+sound.fftSize())>.001f,5000);
    QTRY_VERIFY_WITH_TIMEOUT(!output.empty(),5000);
    auto lit=[&]{for(const auto &event:output)for(QRgb color:event[0].value<QList<QRgb>>())if((color&0xffffff)!=0)return true;return false;};QTRY_VERIFY_WITH_TIMEOUT(lit(),5000);
    sound.start(false);PlaySoundW(nullptr,nullptr,0);
 }
 void independentModeBrightness(){
    using SettingsScope::Settings;
    Settings::setLightpackMode(Lightpack::AmbilightMode);Settings::setDeviceBrightness(81);
    Settings::setLightpackMode(Lightpack::MoodLampMode);Settings::setDeviceBrightness(42);
    Settings::setLightpackMode(Lightpack::SoundVisualizeMode);Settings::setDeviceBrightness(23);
    QCOMPARE(Settings::getDeviceBrightness(),23);
    Settings::setLightpackMode(Lightpack::AmbilightMode);QCOMPARE(Settings::getDeviceBrightness(),81);
    Settings::setLightpackMode(Lightpack::MoodLampMode);QCOMPARE(Settings::getDeviceBrightness(),42);
 }
 void budgetEffects(){
    for(int n:{1,28,54,156,300,312,350})for(int effect=0;effect<6;++effect){auto first=rcxEffectFrame(effect,Qt::blue,n,0,50);auto later=rcxEffectFrame(effect,Qt::blue,n,937,50);QCOMPARE(first.size(),n);QCOMPARE(later.size(),n);if(effect==0)QCOMPARE(first,later);else QVERIFY(first!=later);}
    auto rainbow=rcxEffectFrame(3,Qt::red,54,0,50);QVERIFY(rainbow[0]!=rainbow[13]);
    QCOMPARE(rcxIntervalForHz(60),17);QCOMPARE(rcxIntervalForHz(144),7);QCOMPARE(rcxIntervalForHz(240),5);QCOMPARE(rcxIntervalForHz(0),17);
 }
 void bassAndSensitivity(){
    QVector<float> fft(1024,0.f);fft[4]=.001f;fft[100]=.05f;
    auto all=rcxAudioSpectrum(fft.constData(),1024,48000,false,100);QVERIFY(all[100]>.049f);
    auto quiet=rcxAudioSpectrum(fft.constData(),1024,48000,true,100);QCOMPARE(quiet[4],0.f);QCOMPARE(quiet[100],0.f);
    auto sensitive=rcxAudioSpectrum(fft.constData(),1024,48000,true,400);QVERIFY(sensitive[4]>.0039f);QCOMPARE(sensitive[100],0.f);
    fft[4]=.03f;auto bass=rcxAudioSpectrum(fft.constData(),1024,48000,true,100);QCOMPARE(bass[4],.03f);
    double deadline=0;for(int frame=0;frame<750;++frame)deadline+=1000.0/75.0;QVERIFY(std::abs(deadline-10000.0)<.00001);
    QVERIFY(SettingsScope::Settings::getGrabPeriodMs()>0);
 }
  void twinPeaksExtent(){
    auto extent=[](float amplitude,int sensitivity,int count){
      std::unique_ptr<SoundVisualizerBase> v(SoundVisualizerBase::createWithID(1));
      v->setLiquidMode(false);v->setMinColor(Qt::black);v->setMaxColor(Qt::red);
      QList<QRgb> colors;for(int i=0;i<count;++i)colors<<0;
      QVector<float> fft(1024,0.f);fft[4]=amplitude;
      auto filtered=rcxAudioSpectrum(fft.constData(),fft.size(),48000,true,sensitivity);
      for(int i=0;i<30;++i)v->visualize(filtered.constData(),filtered.size(),colors);
      int lit=0;for(int i=0;i<count;++i){if(colors[i]&0xffffff)++lit;if(colors[i]!=colors[count-1-i])return -1;}
      return lit;
    };
    const int low=extent(.008f,100,66),medium=extent(.04f,100,66),high=extent(.12f,100,66);
    QVERIFY(low>0 && low<medium && medium<high);QCOMPARE(high,66);
    QVERIFY(extent(.04f,25,66)<extent(.04f,400,66));
    QCOMPARE(extent(0,400,66),0);QCOMPARE(extent(.12f,100,1),1);QCOMPARE(extent(.12f,100,65),65);
  }
  void volumeIndependentBeats(){
    auto frames=[](double volume,int sensitivity){
      RcxAudioLevel normalizer;std::unique_ptr<SoundVisualizerBase> visual(SoundVisualizerBase::createWithID(1));
      visual->setLiquidMode(false);visual->setMaxColor(Qt::red);QList<QRgb> colors;for(int i=0;i<66;++i)colors<<0;
      QVector<int> counts;
      for(int frame=0;frame<120;++frame){
        QVector<float> fft(1024,0.f);const double beat=(frame%20<5)?0.06:0.012;
        fft[4]=float(beat*volume);fft[40]=float(.02*volume);
        normalizer.normalize(fft.data(),fft.size(),.025);
        auto filtered=rcxAudioSpectrum(fft.constData(),fft.size(),48000,true,sensitivity);
        visual->visualize(filtered.constData(),filtered.size(),colors);
        int count=0;for(auto c:colors)if(c&0xffffff)++count;counts.append(count);
      }
      return counts;
    };
    const auto standard=frames(1,100);
    for(double gain:{.001,.01,.1,.5,2.,8.})QCOMPARE(frames(gain,100),standard);
    QVERIFY(*std::max_element(standard.begin(),standard.end())>*std::min_element(standard.begin(),standard.end()));
    auto low=frames(.1,25),high=frames(.1,400);QVERIFY(*std::max_element(low.begin(),low.end())<*std::max_element(high.begin(),high.end()));
    RcxAudioLevel level;QVector<float> fft(1024,0.f);fft[4]=.02f;level.normalize(fft.data(),fft.size(),.025);
    fft.fill(0);for(int i=0;i<16;++i)level.normalize(fft.data(),fft.size(),.025);for(auto v:fft)QCOMPARE(v,0.f);
    fft[4]=.00002f;level.normalize(fft.data(),fft.size(),.025);QVERIFY(std::abs(fft[4]-.075f)<.00001f);
    fft.fill(0);fft[4]=std::numeric_limits<float>::quiet_NaN();level.normalize(fft.data(),fft.size(),.025);for(auto v:fft)QCOMPARE(v,0.f);
  }
  void windowsVolumeIndependentAudio(){
    RcxWasapiSoundManager sound;sound.setDevice(-1);sound.start(true);
    IMMDeviceEnumerator *enumerator=nullptr;IMMDevice *device=nullptr;IAudioEndpointVolume *volume=nullptr;
    QVERIFY(SUCCEEDED(CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),reinterpret_cast<void**>(&enumerator))));
    QVERIFY(SUCCEEDED(enumerator->GetDefaultAudioEndpoint(eRender,eMultimedia,&device)));
    QVERIFY(SUCCEEDED(device->Activate(__uuidof(IAudioEndpointVolume),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(&volume))));
    float original=0;BOOL mute=FALSE;volume->GetMasterVolumeLevelScalar(&original);volume->GetMute(&mute);
    struct Restore{IAudioEndpointVolume *v;IMMDevice *d;IMMDeviceEnumerator *e;float gain;BOOL mute;~Restore(){PlaySoundW(nullptr,nullptr,0);v->SetMasterVolumeLevelScalar(gain,nullptr);v->SetMute(mute,nullptr);v->Release();d->Release();e->Release();}} restore{volume,device,enumerator,original,mute};
    volume->SetMute(FALSE,nullptr);
    const int samples=44100;QByteArray pcm;pcm.resize(samples*2);
    for(int i=0;i<samples;++i){qint16 v=qint16(1200*std::sin(2*3.141592653589793*60*i/44100)+800*std::sin(2*3.141592653589793*440*i/44100));pcm[i*2]=char(v&255);pcm[i*2+1]=char((v>>8)&255);}
    QByteArray wav("RIFF");auto put32=[&](quint32 v){for(int i=0;i<4;++i)wav.append(char(v>>(8*i)));};auto put16=[&](quint16 v){wav.append(char(v));wav.append(char(v>>8));};
    put32(pcm.size()+36);wav.append("WAVEfmt ");put32(16);put16(1);put16(1);put32(44100);put32(88200);put16(2);put16(16);wav.append("data");put32(pcm.size());wav.append(pcm);
    QString path=m_dir.path()+"/volume-tone.wav";QFile file(path);QVERIFY(file.open(QIODevice::WriteOnly));file.write(wav);file.close();
    QVERIFY(PlaySoundW(reinterpret_cast<LPCWSTR>(path.utf16()),nullptr,SND_FILENAME|SND_ASYNC|SND_LOOP|SND_NODEFAULT));
    QVector<double> levels;QJsonArray hardware;
    auto captureHardware=[&](const QString &kind,float gain){
      const QString path=qEnvironmentVariable("RCX_AUDIO_HARDWARE_STATUS");if(path.isEmpty())return;
      // The status file is a slow connection heartbeat. Query live counters
      // through the authenticated local control channel for the actual frame.
      QJsonObject status;QFile descriptor(QFileInfo(path).absolutePath()+"/rcx-control.json");
      if(descriptor.open(QIODevice::ReadOnly)){
        const auto d=QJsonDocument::fromJson(descriptor.readAll()).object();QTcpSocket socket;
        socket.connectToHost("127.0.0.1",quint16(d.value("port").toInt()));
        if(socket.waitForConnected(2000)){
          socket.write(QJsonDocument(QJsonObject{{"token",d.value("token")},{"command","snapshot"}}).toJson(QJsonDocument::Compact)+"\n");socket.waitForBytesWritten(2000);
          QByteArray response;for(int attempt=0;attempt<10&&!response.contains('\n');++attempt){if(socket.waitForReadyRead(500))response+=socket.readAll();}
          const auto reply=QJsonDocument::fromJson(response).object();if(reply.value("ok").toBool()){status=reply.value("controller").toObject();status.insert("pid",reply.value("pid"));status.insert("connected",!status.isEmpty());}
        }
      }
      status.insert("testVolume",double(gain));status.insert("testKind",kind);hardware.append(status);
    };
    for(float gain:{.2f,.8f,.1f,1.f}){
      QVERIFY(SUCCEEDED(volume->SetMasterVolumeLevelScalar(gain,nullptr)));QTest::qWait(350);
      QTRY_VERIFY_WITH_TIMEOUT(*std::max_element(sound.fft(),sound.fft()+sound.fftSize())>.005f,5000);QTest::qWait(300);
      double mean=0,full=0;for(int frame=0;frame<8;++frame){QTest::qWait(30);double energy=0,all=0;for(size_t k=1;k<sound.fftSize();++k)all+=double(sound.fft()[k])*sound.fft()[k];full+=std::sqrt(all)/8;auto fft=rcxAudioSpectrum(sound.fft(),int(sound.fftSize()),sound.sampleRate(),true,100);for(auto f:fft)energy+=double(f)*f;mean+=std::sqrt(energy)/8;}
      qInfo()<<"RCX individual endpoint gain"<<gain<<"bass"<<mean<<"full"<<full;
      levels.append(mean);QVERIFY2(mean>.005,qPrintable(QString("Endpoint gain %1, bass %2").arg(gain).arg(mean)));
      captureHardware("endpoint",gain);
    }
    const auto range=std::minmax_element(levels.begin(),levels.end());QVERIFY2(*range.second-*range.first<.008,qPrintable(QString("Normalized bass levels: %1 %2 %3 %4").arg(levels[0]).arg(levels[1]).arg(levels[2]).arg(levels[3])));
    qInfo()<<"RCX Windows volume 20/80/10/100%, normalized bass"<<levels;
    IAudioSessionManager2 *manager=nullptr;IAudioSessionEnumerator *sessions=nullptr;ISimpleAudioVolume *sessionVolume=nullptr;
    QVERIFY(SUCCEEDED(device->Activate(__uuidof(IAudioSessionManager2),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(&manager))));
    QVERIFY(SUCCEEDED(manager->GetSessionEnumerator(&sessions)));int count=0;sessions->GetCount(&count);
    for(int i=0;i<count&&!sessionVolume;++i){IAudioSessionControl *control=nullptr;IAudioSessionControl2 *identity=nullptr;
      if(SUCCEEDED(sessions->GetSession(i,&control))){
        if(SUCCEEDED(control->QueryInterface(__uuidof(IAudioSessionControl2),reinterpret_cast<void**>(&identity)))){DWORD pid=0;identity->GetProcessId(&pid);if(pid==GetCurrentProcessId())control->QueryInterface(__uuidof(ISimpleAudioVolume),reinterpret_cast<void**>(&sessionVolume));identity->Release();}
        control->Release();
      }
    }
    sessions->Release();manager->Release();QVERIFY(sessionVolume);
    float originalSession=1;BOOL sessionMute=FALSE;sessionVolume->GetMasterVolume(&originalSession);sessionVolume->GetMute(&sessionMute);
    struct RestoreSession{ISimpleAudioVolume *v;float gain;BOOL mute;~RestoreSession(){v->SetMasterVolume(gain,nullptr);v->SetMute(mute,nullptr);v->Release();}} restoreSession{sessionVolume,originalSession,sessionMute};
    sessionVolume->SetMute(FALSE,nullptr);levels.clear();
    for(float gain:{.1f,.9f,.2f,1.f}){
      QVERIFY(SUCCEEDED(sessionVolume->SetMasterVolume(gain,nullptr)));QTest::qWait(350);
      QTRY_VERIFY_WITH_TIMEOUT(*std::max_element(sound.fft(),sound.fft()+sound.fftSize())>.005f,5000);QTest::qWait(300);
      double mean=0,full=0;for(int frame=0;frame<8;++frame){QTest::qWait(30);double energy=0,all=0;for(size_t k=1;k<sound.fftSize();++k)all+=double(sound.fft()[k])*sound.fft()[k];full+=std::sqrt(all)/8;auto fft=rcxAudioSpectrum(sound.fft(),int(sound.fftSize()),sound.sampleRate(),true,100);for(auto f:fft)energy+=double(f)*f;mean+=std::sqrt(energy)/8;}
      qInfo()<<"RCX individual session gain"<<gain<<"bass"<<mean<<"full"<<full;
      levels.append(mean);QVERIFY2(mean>.005,qPrintable(QString("Session gain %1, bass %2").arg(gain).arg(mean)));
      captureHardware("session",gain);
    }
    const auto sessionRange=std::minmax_element(levels.begin(),levels.end());QVERIFY(*sessionRange.second-*sessionRange.first<.008);
    qInfo()<<"RCX session volume 10/90/20/100%, normalized bass"<<levels;
    if(!qEnvironmentVariable("RCX_AUDIO_HARDWARE_REPORT").isEmpty()){
      QFile f(qEnvironmentVariable("RCX_AUDIO_HARDWARE_REPORT"));QVERIFY(f.open(QIODevice::WriteOnly));f.write(QJsonDocument(hardware).toJson());
    }
    sound.start(false);
  }
 void audioBottomCenterMapping(){
    QList<QRect> zones{QRect(90,80,10,20),QRect(90,0,10,20),QRect(0,0,20,10),QRect(0,80,10,20),QRect(0,90,20,10),QRect(40,90,20,10),QRect(80,90,20,10)};
    QCOMPARE(rcxBottomCenterOffset(zones),5);
    QList<QRgb> frame{qRgb(255,0,0),0,0,0,0,0,qRgb(255,0,0)};auto rotated=rcxRotateSound(frame,5);QCOMPARE(rotated[5],frame[0]);QCOMPARE(rotated[4],frame[6]);
    QCOMPARE(rcxRotateSound(QList<QRgb>{qRgb(255,0,0)},20).size(),1);
 }
};
QTEST_MAIN(RcxTests)
#include "tst_rcx.moc"
