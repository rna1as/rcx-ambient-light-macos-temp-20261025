// RCX host audio gain normalization, GPL-3.0-or-later.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
class RcxAudioLevel {
    double m_reference=0;
    double m_hold=0;
    double m_silence=0;
public:
    void reset(){m_reference=0;m_hold=0;m_silence=0;}
    void normalize(float *fft,std::size_t count,double seconds){
        double energy=0;
        for(std::size_t i=0;i<count;++i){
            if(!std::isfinite(fft[i])||fft[i]<0)fft[i]=0;
            if(i)energy+=double(fft[i])*fft[i];
        }
        const double level=std::sqrt(energy);
        seconds=std::max(0.001,std::min(seconds,0.25));
        // A digital silence gate must precede gain, or empty/noisy buffers can
        // be amplified into a full strip. The tiny floor is below normal music.
        if(level<1e-7){
            std::fill(fft,fft+count,0.f);m_silence+=seconds;
            if(m_silence>=0.3)reset();
            return;
        }
        m_silence=0;
        if(m_reference==0||level>=m_reference){m_reference=level;m_hold=0.5;}
        else if(m_hold>0)m_hold=std::max(0.0,m_hold-seconds);
        else m_reference=std::max(level,m_reference*std::exp(-seconds/0.55));
        // Normalize the complete spectrum before selecting bass and applying
        // user sensitivity. Holding the reference preserves quieter beats.
        const double gain=0.075/m_reference;
        fft[0]=0;
        for(std::size_t i=1;i<count;++i)fft[i]=float(fft[i]*gain);
    }
};
