// RCX effects, GPL-3.0-or-later. Pure host-side rendering; firmware is unchanged.
#pragma once
#include <QColor>
#include <QList>
#include <QVector>
#include <QRect>
#include <cmath>
#include <algorithm>
inline QList<QRgb> rcxEffectFrame(int effect,const QColor &base,int count,qint64 ms,int speed){
 QList<QRgb> frame;const double pi=3.141592653589793;const double t=ms/1000.0*(.15+qBound(1,speed,100)/35.0);
 for(int i=0;i<count;++i){QColor c=base;const double x=count>1?double(i)/(count-1):0;
  if(effect==1)c=QColor::fromHsvF(std::fmod(t*.09,1.0),1,1);
  else if(effect==2){double v=(1-std::cos(t*pi))*.5;c.setRgbF(base.redF()*v,base.greenF()*v,base.blueF()*v);}
  else if(effect==3)c=QColor::fromHsvF(std::fmod(x+t*.12,1.0),1,1);
  else if(effect==4){double v=std::pow((1+std::cos(2*pi*(x-t*.22)))*.5,3);c.setRgbF(base.redF()*v,base.greenF()*v,base.blueF()*v);}
  else if(effect==5){double heat=qBound(0.0,.50+.24*std::sin(t*2.1+i*.7)+.16*std::sin(t*4.7-i*.37),1.0);c.setRgb(255,int(20+heat*200),int(std::max(0.0,heat-.8)*60));c.setRgbF(c.redF()*(.35+.65*heat),c.greenF()*(.35+.65*heat),c.blueF());}
  frame.append(c.rgb());
 }return frame;
}
inline QList<QRgb> rcxRotateSound(const QList<QRgb> &frame,int offset){
 if(frame.empty())return frame;QList<QRgb> result=frame;const int n=frame.size();offset=((offset%n)+n)%n;
 for(int i=0;i<n;++i)result[(i+offset)%n]=frame[i];return result;
}
inline int rcxBottomCenterOffset(const QList<QRect> &zones){
 if(zones.empty())return 0;QRect bounds;for(const auto &z:zones)bounds=bounds.united(z);
 const QPoint center(bounds.center().x(),bounds.bottom());int index=0;double distance=1e30;
 for(int i=0;i<zones.size();++i){const QPoint p=zones[i].center()-center;double d=double(p.x())*p.x()+double(p.y())*p.y();if(d<distance){distance=d;index=i;}}
 return index;
}
inline int rcxIntervalForHz(double hz){if(!std::isfinite(hz)||hz<1)hz=60;return std::max(1,int(std::ceil(1000.0/hz)));}

inline QVector<float> rcxAudioSpectrum(const float *fft,int count,double sampleRate,bool bassOnly,int sensitivity){
 QVector<float> result;result.reserve(count);const float gain=qBound(25,sensitivity,400)/100.f;double energy=0;
 for(int i=0;i<count;++i){double hz=i*sampleRate/(count*2.0);float v=(!bassOnly||(hz>=20&&hz<=180))?fft[i]*gain:0;result.append(v);energy+=v*v;}
 // Sensitivity changes the minimum audible energy; upstream peak normalization alone cancels a constant gain.
 if(std::sqrt(energy)<.0015)for(auto &v:result)v=0;
 return result;
}
