// RCX additions, GPL-3.0-or-later.
#pragma once
#include <QObject>
#include <QMap>
#include <QProcess>
#include <QTimer>
class RcxWorkers : public QObject {
public:
    explicit RcxWorkers(const QString &configDir, QObject *parent);
    ~RcxWorkers() override;
public:
    void reconcile();
private:
    QString m_dir;
    QMap<QString, QProcess *> m_workers;
    QTimer *m_timer;
    void *m_job{nullptr};
};
