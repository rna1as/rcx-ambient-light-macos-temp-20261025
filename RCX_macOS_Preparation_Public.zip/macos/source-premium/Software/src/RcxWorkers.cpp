// RCX additions, GPL-3.0-or-later. Only primary launches workers, no BAT/startup per worker.
#include "RcxWorkers.hpp"
#include <QSettings>
#include <QDir>
#include <QCoreApplication>
#include <QProcessEnvironment>
#include <QSet>
#ifdef Q_OS_WIN
#include <windows.h>
#endif
RcxWorkers::RcxWorkers(const QString &configDir, QObject *parent) : QObject(parent), m_dir(configDir) {
#ifdef Q_OS_WIN
    auto job = CreateJobObjectW(nullptr, nullptr);
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limit{};
    limit.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (job && SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limit, sizeof(limit))) m_job = job;
    else if (job) CloseHandle(job);
#endif
    m_timer = new QTimer(this); m_timer->setInterval(2000);
    connect(m_timer, &QTimer::timeout, this, [this] { reconcile(); });
    m_timer->start(); reconcile();
}
RcxWorkers::~RcxWorkers() {
    m_timer->stop();
    for (auto *p : m_workers) {
        // RCX workers poll the primary's PID as well, so crash cleanup has a fallback.
        QProcess::execute(QCoreApplication::applicationFilePath(), {"--rcx-shutdown", "--config-dir", m_workers.key(p)});
        if (!p->waitForFinished(2000)) { p->kill(); p->waitForFinished(1000); }
    }
#ifdef Q_OS_WIN
    if (m_job) CloseHandle(m_job);
#endif
}
void RcxWorkers::reconcile() {
    QSettings conf(m_dir + "/main.conf", QSettings::IniFormat);
    const auto relative = conf.value("RCX/WorkerConfigs").toString().split('|', Qt::SkipEmptyParts);
    QSet<QString> wanted, ids;
    ids.insert(conf.value("RCX/DeviceId").toString().toUpper());
    for (const auto &entry : relative) {
        // Worker configs are owned children of this installation's user config tree.
        const QString path = QDir::cleanPath(m_dir + '/' + entry);
        if (!path.startsWith(QDir::cleanPath(m_dir) + "/Controllers/") || !QFile::exists(path + "/main.conf")) continue;
        QSettings worker(path + "/main.conf", QSettings::IniFormat);
        const auto id = worker.value("RCX/DeviceId").toString().toUpper();
        if (id.isEmpty() || ids.contains(id)) continue;
        ids.insert(id); wanted.insert(path);
        auto *p = m_workers.value(path, nullptr);
        if (!p) { p = new QProcess(this); m_workers.insert(path, p); }
        if (p->state() != QProcess::NotRunning) continue;
        auto env = QProcessEnvironment::systemEnvironment();
        env.insert("RCX_PARENT_PID", QString::number(QCoreApplication::applicationPid()));
        p->setProcessEnvironment(env);
        p->setStandardOutputFile(path + "/worker.stdout.log");
        p->setStandardErrorFile(path + "/worker.stderr.log");
        p->start(QCoreApplication::applicationFilePath(), {"--rcx-worker", "--config-dir", path});
#ifdef Q_OS_WIN
        if (p->waitForStarted(1000) && m_job) {
            auto handle = OpenProcess(PROCESS_SET_QUOTA | PROCESS_TERMINATE, FALSE, DWORD(p->processId()));
            if (handle) { AssignProcessToJobObject(m_job, handle); CloseHandle(handle); }
        }
#endif
    }
    for (auto it = m_workers.begin(); it != m_workers.end();) {
        if (wanted.contains(it.key())) { ++it; continue; }
        auto *p = it.value(); p->kill(); p->waitForFinished(1000); p->deleteLater(); it = m_workers.erase(it);
    }
}
