// RCX additions, GPL-3.0-or-later. Firmware identity contract, no setting writes.
#pragma once
#include <QMap>
#include <QString>
#include <QRegularExpression>
inline QMap<QString, QString> rcxIdentity(const QByteArray &line) {
    QMap<QString, QString> fields;
    const auto parts = QString::fromLatin1(line.trimmed()).split(';');
    if (parts.isEmpty() || parts.first() != QStringLiteral("RCX_AMBILIGHT_V1")) return {};
    for (int i = 1; i < parts.size(); ++i) {
        const int eq = parts[i].indexOf('=');
        if (eq <= 0) continue;
        const auto key = parts[i].left(eq);
        if (fields.contains(key)) return {}; // Ambiguous identity is never accepted.
        fields.insert(key, parts[i].mid(eq + 1));
    }
    if (!QRegularExpression(QStringLiteral("^[0-9A-Fa-f]{6}$")).match(fields.value("ID")).hasMatch()
        || fields.value("MODEL") != "RCX-AMBI-S300" || (fields.value("MAX") != "300" && fields.value("MAX") != "350")
        || fields.value("BAUD") != "921600" || fields.value("FW").isEmpty()
        || fields.value("SERIAL").isEmpty()) return {};
    fields["ID"] = fields["ID"].toUpper();
    return fields;
}
