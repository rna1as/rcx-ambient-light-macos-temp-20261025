// RCX additions, GPL-3.0-or-later.
#include "RcxWasapiSoundManager.hpp"
#include <propsys.h>
static const PROPERTYKEY RcxFriendlyName = {{0xa45c254e,0xdf1c,0x4efd,{0x80,0x20,0x67,0xd1,0x46,0xa8,0x50,0xe0}},14};
#include <ksmedia.h>
#include <complex>
#include <vector>
#include <algorithm>
#include <cstring>
#include <QDebug>
#include <QMap>
RcxWasapiSoundManager::RcxWasapiSoundManager(QObject *parent):SoundManagerBase(parent){
    m_timer.setInterval(25);connect(&m_timer,&QTimer::timeout,this,&SoundManagerBase::updateColors);
}
RcxWasapiSoundManager::~RcxWasapiSoundManager(){start(false);if(m_enumerator)m_enumerator->Release();if(m_com)CoUninitialize();}
bool RcxWasapiSoundManager::init(){
    if(m_enumerator)return true;
    HRESULT hr=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);m_com=SUCCEEDED(hr);
    if(FAILED(hr)&&hr!=RPC_E_CHANGED_MODE)return false;
    hr=CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),reinterpret_cast<void**>(&m_enumerator));
    m_isInited=SUCCEEDED(hr);return m_isInited;
}
void RcxWasapiSoundManager::populateDeviceList(QList<SoundManagerDeviceInfo>& devices,int& recommended){
    recommended=-1;devices.append(SoundManagerDeviceInfo(tr("Default speakers (system audio)"),-1));
    IMMDeviceCollection *list=nullptr;if(FAILED(m_enumerator->EnumAudioEndpoints(eRender,DEVICE_STATE_ACTIVE,&list)))return;
    UINT count=0;list->GetCount(&count);
    for(UINT i=0;i<count;++i){IMMDevice *device=nullptr;IPropertyStore *properties=nullptr;list->Item(i,&device);QString name=tr("Audio output %1").arg(i+1);
        if(device&&SUCCEEDED(device->OpenPropertyStore(STGM_READ,&properties))){PROPVARIANT v;PropVariantInit(&v);if(SUCCEEDED(properties->GetValue(RcxFriendlyName,&v))&&v.vt==VT_LPWSTR)name=QString::fromWCharArray(v.pwszVal);PropVariantClear(&v);properties->Release();}
        devices.append(SoundManagerDeviceInfo(name,int(i)));if(device)device->Release();}
    list->Release();
}
void RcxWasapiSoundManager::releaseCapture(){
    if(m_client)m_client->Stop();if(m_capture){m_capture->Release();m_capture=nullptr;}if(m_client){m_client->Release();m_client=nullptr;}
    if(m_format){CoTaskMemFree(m_format);m_format=nullptr;}m_samples.clear();std::fill(m_fft,m_fft+fftSize(),0.f);
    m_volumeMonitor.reset();
    m_audioLevel.reset();m_volumeState.clear();
}
void RcxWasapiSoundManager::start(bool enabled){
    if(enabled==m_isEnabled)return;
    m_timer.stop();releaseCapture();m_isEnabled=false;
    if(!enabled){if(m_visualizer)m_visualizer->stop();return;}
    if(!init())return;
    IMMDevice *device=nullptr;HRESULT hr;
    if(m_device<0)hr=m_enumerator->GetDefaultAudioEndpoint(eRender,eMultimedia,&device);
    else {IMMDeviceCollection *list=nullptr;hr=m_enumerator->EnumAudioEndpoints(eRender,DEVICE_STATE_ACTIVE,&list);if(SUCCEEDED(hr)){hr=list->Item(UINT(m_device),&device);list->Release();}}
    if(SUCCEEDED(hr)){LPWSTR id=nullptr;if(SUCCEEDED(device->GetId(&id))){m_endpointId=QString::fromWCharArray(id);CoTaskMemFree(id);}}
    if(SUCCEEDED(hr))hr=device->Activate(__uuidof(IAudioClient),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(&m_client));
    if(device)device->Release();
    if(SUCCEEDED(hr))hr=m_client->GetMixFormat(&m_format);
    if(SUCCEEDED(hr))hr=m_client->Initialize(AUDCLNT_SHAREMODE_SHARED,AUDCLNT_STREAMFLAGS_LOOPBACK,1000000,0,m_format,nullptr);
    if(SUCCEEDED(hr))hr=m_client->GetService(__uuidof(IAudioCaptureClient),reinterpret_cast<void**>(&m_capture));
    if(SUCCEEDED(hr))hr=m_client->Start();
    if(FAILED(hr)){qWarning()<<"RCX WASAPI capture unavailable"<<QString::number(quint32(hr),16);releaseCapture();return;}
    m_isEnabled=true;m_lastPacket.start();m_endpointCheck.start();if(m_visualizer)m_visualizer->start();m_timer.start();
    m_volumeMonitor.reset(new RcxAudioVolumeMonitor(m_endpointId));m_volumeMonitor->start();
    m_volumeState=m_volumeMonitor->state();m_volumeCheck.start();m_levelClock.start();m_gainSettle.start();
}
void RcxWasapiSoundManager::updateFft(){
    if(!m_capture||!m_format)return;
    if(m_volumeCheck.elapsed()>=100){
        m_volumeCheck.restart();const auto state=m_volumeMonitor?m_volumeMonitor->state():QByteArray();
        if(state!=m_volumeState){m_volumeState=state;m_audioLevel.reset();m_gainSettle.restart();}
    }
 if(m_endpointCheck.elapsed()>1000){m_endpointCheck.restart();IMMDevice *current=nullptr;LPWSTR id=nullptr;QString name;
 if(SUCCEEDED(m_enumerator->GetDefaultAudioEndpoint(eRender,eMultimedia,&current))){if(SUCCEEDED(current->GetId(&id))){name=QString::fromWCharArray(id);CoTaskMemFree(id);}current->Release();}
 if(!name.isEmpty()&&name!=m_endpointId){start(false);start(true);return;}}
    UINT packet=0;HRESULT hr=m_capture->GetNextPacketSize(&packet);
    while(SUCCEEDED(hr)&&packet){BYTE *data=nullptr;UINT frames=0;DWORD flags=0;hr=m_capture->GetBuffer(&data,&frames,&flags,nullptr,nullptr);if(FAILED(hr))break;
        const int bytes=m_format->wBitsPerSample/8;bool floating=m_format->wFormatTag==WAVE_FORMAT_IEEE_FLOAT;
        if(m_format->wFormatTag==WAVE_FORMAT_EXTENSIBLE)floating=reinterpret_cast<WAVEFORMATEXTENSIBLE*>(m_format)->SubFormat.Data1==WAVE_FORMAT_IEEE_FLOAT;
        for(UINT i=0;i<frames;++i){float sample=0;
            if(!(flags&AUDCLNT_BUFFERFLAGS_SILENT))for(int c=0;c<m_format->nChannels;++c){const BYTE *p=data+i*m_format->nBlockAlign+c*bytes;float v=0;
                if(floating&&bytes==4)std::memcpy(&v,p,4);
                else if(bytes==2){short x;std::memcpy(&x,p,2);v=x/32768.f;}
                else if(bytes==3){int x=int(p[0])|(int(p[1])<<8)|(int(p[2])<<16);if(x&0x800000)x|=~0xffffff;v=x/8388608.f;}
                else if(bytes==4){int x;std::memcpy(&x,p,4);v=x/2147483648.f;}sample+=v/m_format->nChannels;}
            m_samples.push_back(sample);if(m_samples.size()>fftSize()*2)m_samples.pop_front();}
        m_capture->ReleaseBuffer(frames);m_lastPacket.restart();hr=m_capture->GetNextPacketSize(&packet);
    }
    if(FAILED(hr)){qWarning()<<"RCX WASAPI packet failure"<<QString::number(quint32(hr),16);start(false);return;}if(m_lastPacket.elapsed()>150)m_samples.clear();
    const size_t n=fftSize()*2;std::vector<std::complex<float>> bins(n);const double pi=3.141592653589793;
    for(size_t i=0;i<m_samples.size();++i)bins[n-m_samples.size()+i]=m_samples[i]*float(.5-.5*std::cos(2*pi*i/(n-1)));
    for(size_t i=1,j=0;i<n;++i){size_t bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j)std::swap(bins[i],bins[j]);}
    for(size_t len=2;len<=n;len<<=1){std::complex<float> step(float(std::cos(-2*pi/len)),float(std::sin(-2*pi/len)));
        for(size_t i=0;i<n;i+=len){std::complex<float> twiddle(1,0);for(size_t j=0;j<len/2;++j){auto u=bins[i+j],v=bins[i+j+len/2]*twiddle;bins[i+j]=u+v;bins[i+j+len/2]=u-v;twiddle*=step;}}}
    for(size_t i=0;i<fftSize();++i)m_fft[i]=std::abs(bins[i])*2.f/float(n);
    const double seconds=std::max<qint64>(1,m_levelClock.restart())/1000.0;
    // Windows may report a new volume before queued loopback packets reflect
    // it. Do not retain an old-volume peak while that short queue settles.
    if(m_gainSettle.elapsed()<250)m_audioLevel.reset();
    m_audioLevel.normalize(m_fft,fftSize(),seconds);
}
