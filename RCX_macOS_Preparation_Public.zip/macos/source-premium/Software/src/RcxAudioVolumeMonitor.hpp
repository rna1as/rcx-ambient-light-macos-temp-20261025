// Windows mixer monitoring, GPL-3.0-or-later.
#pragma once
#include <QThread>
#include <QMutex>
#include <QMutexLocker>
#include <QMap>
#include <QVector>
#include <atomic>
#include <mmdeviceapi.h>
#include <endpointvolume.h>
#include <audiopolicy.h>

// New render sessions must be retained from an MTA notification callback;
// a long-lived enumerator on the UI apartment can omit newly opened players.
class RcxAudioSessions final : public IAudioSessionNotification {
    std::atomic<ULONG> m_refs{1};
    QMutex m_mutex;
    QVector<IAudioSessionControl*> m_controls;
public:
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void **out) override {
        if(!out)return E_POINTER;*out=nullptr;
        if(id==__uuidof(IUnknown)||id==__uuidof(IAudioSessionNotification)){*out=static_cast<IAudioSessionNotification*>(this);AddRef();return S_OK;}
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override{return ++m_refs;}
    ULONG STDMETHODCALLTYPE Release() override{const ULONG n=--m_refs;if(!n)delete this;return n;}
    HRESULT STDMETHODCALLTYPE OnSessionCreated(IAudioSessionControl *control) override {
        if(!control)return E_POINTER;control->AddRef();QMutexLocker lock(&m_mutex);m_controls.append(control);return S_OK;
    }
    QVector<IAudioSessionControl*> snapshot(){QMutexLocker lock(&m_mutex);auto controls=m_controls;for(auto c:controls)c->AddRef();return controls;}
    void remove(IAudioSessionControl *control){QMutexLocker lock(&m_mutex);for(int i=m_controls.size()-1;i>=0;--i)if(m_controls[i]==control){m_controls.removeAt(i);control->Release();}}
    ~RcxAudioSessions(){for(auto c:m_controls)c->Release();}
};

class RcxAudioVolumeMonitor final : public QThread {
    QString m_endpoint;
    mutable QMutex m_mutex;
    QByteArray m_state;
public:
    explicit RcxAudioVolumeMonitor(const QString &endpoint):m_endpoint(endpoint){}
    ~RcxAudioVolumeMonitor() override{requestInterruption();wait();}
    QByteArray state()const{QMutexLocker lock(&m_mutex);return m_state;}
protected:
    void run() override {
        if(FAILED(CoInitializeEx(nullptr,COINIT_MULTITHREADED)))return;
        IMMDeviceEnumerator *enumerator=nullptr;IMMDevice *device=nullptr;
        IAudioEndpointVolume *volume=nullptr;IAudioSessionManager2 *manager=nullptr;
        auto sessions=new RcxAudioSessions;bool registered=false;
        HRESULT hr=CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,__uuidof(IMMDeviceEnumerator),reinterpret_cast<void**>(&enumerator));
        if(SUCCEEDED(hr))hr=enumerator->GetDevice(reinterpret_cast<LPCWSTR>(m_endpoint.utf16()),&device);
        if(SUCCEEDED(hr)){
            device->Activate(__uuidof(IAudioEndpointVolume),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(&volume));
            if(SUCCEEDED(device->Activate(__uuidof(IAudioSessionManager2),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(&manager)))){
                registered=SUCCEEDED(manager->RegisterSessionNotification(sessions));
                IAudioSessionEnumerator *list=nullptr;
                if(SUCCEEDED(manager->GetSessionEnumerator(&list))){
                    int count=0;list->GetCount(&count); // Enables subsequent session notifications.
                    for(int i=0;i<count;++i){IAudioSessionControl *control=nullptr;if(SUCCEEDED(list->GetSession(i,&control))){sessions->OnSessionCreated(control);control->Release();}}
                    list->Release();
                }
            }
            while(!isInterruptionRequested()){
                QByteArray state;float db=0;BOOL mute=FALSE;
                if(volume){if(SUCCEEDED(volume->GetMasterVolumeLevel(&db)))state+=QByteArray::number(db,'f',4);if(SUCCEEDED(volume->GetMute(&mute)))state+=mute?"M;":"U;";}
                QMap<QString,QByteArray> values;
                for(auto control:sessions->snapshot()){
                    AudioSessionState active=AudioSessionStateInactive;control->GetState(&active);
                    IAudioSessionControl2 *identity=nullptr;ISimpleAudioVolume *gainControl=nullptr;
                    if(active==AudioSessionStateActive&&SUCCEEDED(control->QueryInterface(__uuidof(IAudioSessionControl2),reinterpret_cast<void**>(&identity)))&&SUCCEEDED(control->QueryInterface(__uuidof(ISimpleAudioVolume),reinterpret_cast<void**>(&gainControl)))){
                        LPWSTR id=nullptr;float gain=1;BOOL muted=FALSE;
                        if(SUCCEEDED(identity->GetSessionInstanceIdentifier(&id))){gainControl->GetMasterVolume(&gain);gainControl->GetMute(&muted);values.insert(QString::fromWCharArray(id),QByteArray::number(gain,'f',6)+(muted?"M":"U"));CoTaskMemFree(id);}
                    }
                    if(gainControl)gainControl->Release();if(identity)identity->Release();
                    if(active==AudioSessionStateExpired)sessions->remove(control);
                    control->Release();
                }
                for(auto i=values.cbegin();i!=values.cend();++i)state+=i.key().toUtf8()+"="+i.value()+";";
                {QMutexLocker lock(&m_mutex);m_state=state;}
                msleep(50);
            }
        }
        if(registered)manager->UnregisterSessionNotification(sessions);
        if(manager)manager->Release();sessions->Release();if(volume)volume->Release();if(device)device->Release();if(enumerator)enumerator->Release();CoUninitialize();
    }
};
