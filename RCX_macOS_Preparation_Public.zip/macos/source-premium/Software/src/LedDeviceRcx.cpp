// RCX additions, GPL-3.0-or-later. Standard Adalight output at 921600 baud.
#include "LedDeviceRcx.hpp"
#include "RcxIdentity.hpp"
#include "../../RCXAuth/auth_qt.hpp"
#include <QSerialPortInfo>
#include <QSettings>
#include <QSaveFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDateTime>
#include <QCoreApplication>
#include <QRandomGenerator>
#include <algorithm>

LedDeviceRcx::LedDeviceRcx(const QString &id, const QString &configDir)
    : LedDeviceAdalight(QString(), 921600), m_id(id.toUpper()), m_configDir(configDir) {
    m_retry = new QTimer(this);
    m_retry->setInterval(1500);
    connect(m_retry, &QTimer::timeout, this, &LedDeviceRcx::discover);
    QSettings conf(configDir + "/main.conf", QSettings::IniFormat);
    m_lastPort = conf.value("RCX/LastPort").toString();
    m_legacyID = conf.value("RCX/LegacyDeviceId").toString().toUpper();
}
LedDeviceRcx::~LedDeviceRcx() { close(); }
void LedDeviceRcx::open() {
    if (m_running) return;
    m_running = true;
    publishStatus(false);
    m_retry->start();
    // Keep capture alive while waiting; real connection state is published separately.
    emit openDeviceSuccess(true);
    discover();
}
void LedDeviceRcx::clearProbes() {
    const auto probes = m_probes.keys();
    m_probes.clear();
    m_challenges.clear();m_identities.clear();
    for (auto *p : probes) { p->disconnect(this); p->close(); p->deleteLater(); }
}
void LedDeviceRcx::close() {
    m_running = false;
    m_retry->stop();
    clearProbes();
    m_connected = false;
    LedDeviceAdalight::close();
    publishStatus(false);
}
void LedDeviceRcx::disconnected() {
    if (m_AdalightDevice) {
        m_AdalightDevice->disconnect(this);
        m_AdalightDevice->close();
        m_AdalightDevice->deleteLater();
        m_AdalightDevice = nullptr;
    }
    m_lastWillTimer->stop();
    m_connected = false;
    publishStatus(false);
}
void LedDeviceRcx::discover() {
    if (!m_running) return;
    // Desynchronize controller probes so an absent primary cannot monopolize a worker's UART.
    m_retry->setInterval(1400 + QRandomGenerator::global()->bounded(600));
    if (m_connected) {
        bool present = false;
        for (const auto &port : QSerialPortInfo::availablePorts()) if (port.portName() == m_portName) present = true;
        if (!present) disconnected();
        else { publishStatus(true); return; }
    }
    if (!m_probes.isEmpty()) return;
    publishStatus(false);
    auto ports = QSerialPortInfo::availablePorts();
    std::stable_sort(ports.begin(), ports.end(), [this](const QSerialPortInfo &a, const QSerialPortInfo &b) {
        return a.portName() == m_lastPort && b.portName() != m_lastPort;
    });
    for (const auto &info : ports) {
        auto *p = new QSerialPort(info, this);
        if (info.hasVendorIdentifier() && info.vendorIdentifier() != 0x1a86
            && info.vendorIdentifier() != 0x10c4 && info.vendorIdentifier() != 0x0403) { delete p; continue; }
        p->setBaudRate(921600); p->setDataBits(QSerialPort::Data8);
        p->setParity(QSerialPort::NoParity); p->setStopBits(QSerialPort::OneStop);
        p->setFlowControl(QSerialPort::NoFlowControl);
        // Bluetooth virtual ports cannot be RCX's USB UART; avoid initiating BT connections.
        if (info.description().contains("Bluetooth", Qt::CaseInsensitive) || !p->open(QIODevice::ReadWrite)) {
            delete p; continue;
        }
        // Do not assert DTR/RTS: this must not reset or enter the ESP bootloader.
        p->setDataTerminalReady(false); p->setRequestToSend(false);
        m_probes.insert(p, {});
        connect(p, &QSerialPort::readyRead, this, [this, p] {
            if (!m_probes.contains(p)) return;
            auto &buffer = m_probes[p]; buffer += p->readAll();
            while (buffer.contains('\n')) {
                const int end = buffer.indexOf('\n');
                const auto line = buffer.left(end); buffer.remove(0, end + 1);
                const auto identity = rcxIdentity(line);
                if (m_challenges.contains(p)&&rcxVerify(line,m_id,m_challenges.value(p))){auto verified=m_identities.take(p);m_challenges.remove(p);accept(p,verified);return;}
                if (identity.value("ID") == m_id && !m_id.isEmpty()) {
                    if(identity.value("AUTH")=="1"){
                        if(!m_challenges.contains(p)){auto nonce=rcxRandom(32);if(nonce.size()!=32)return;m_challenges[p]=nonce;m_identities[p]=identity;p->write("RCXAUTH;N="+nonce.toHex()+"\n");}
                        continue;
                    }
                    if(rcxLegacyAllowed(identity,m_legacyID)){accept(p,identity);return;}
                }
                if (!identity.isEmpty()) {
                    // This controller belongs to another worker: release its UART immediately.
                    m_probes.remove(p); p->disconnect(this); p->close(); p->deleteLater(); return;
                }
            }
            if (buffer.size() > 2048) buffer.clear();
        });
        // Allow firmware to settle after Windows exposes a USB UART, then query twice.
        QTimer::singleShot(100, p, [this, p] { if (m_probes.contains(p)) p->write("RCX?\n"); });
        QTimer::singleShot(500, p, [this, p] { if (m_probes.contains(p)) p->write("RCX?\n"); });
        QTimer::singleShot(2200, p, [this, p] {
            if (!m_probes.remove(p)) return;
            m_challenges.remove(p);m_identities.remove(p);
            p->disconnect(this); p->close(); p->deleteLater();
        });
    }
}
void LedDeviceRcx::accept(QSerialPort *p, const QMap<QString, QString> &identity) {
    m_probes.remove(p); p->disconnect(this);
    clearProbes();
    m_AdalightDevice = p;
    m_portName = m_lastPort = p->portName();
    m_firmware = identity.value("FW");
    m_maxLeds = qBound(1, identity.value("MAX").toInt(), 350);
    m_connected = true;
    connect(p, &QSerialPort::readyRead, this, [p] { p->readAll(); });
    connect(p, &QSerialPort::errorOccurred, this, [this](QSerialPort::SerialPortError error) {
        if (error == QSerialPort::ResourceError || error == QSerialPort::DeviceNotFoundError
            || error == QSerialPort::PermissionError || error == QSerialPort::WriteError) disconnected();
    });
    QSettings conf(m_configDir + "/main.conf", QSettings::IniFormat);
    conf.setValue("RCX/LastPort", m_lastPort); conf.sync();
    publishStatus(true);
    emit openDeviceSuccess(true);
    setColors(m_colorsSaved);
}
bool LedDeviceRcx::writeBuffer(const QByteArray &buffer) {
    if (!m_connected || !m_AdalightDevice) return true; // Latest capture is retained by Adalight.
    if (buffer.size() > 6 + m_maxLeds * 3) return true;
    if (m_AdalightDevice->bytesToWrite() > 0) {
        m_lastWillTimer->start(100); return true;
    }
    m_lastWillTimer->stop();
    if (m_AdalightDevice->write(buffer) != buffer.size()) disconnected();
    else {
        ++m_framesSent;
        m_lastFrameAt=QDateTime::currentMSecsSinceEpoch();
        m_lastLitLeds=0;for(int i=6;i+2<buffer.size();i+=3)if(buffer[i]!=0||buffer[i+1]!=0||buffer[i+2]!=0)++m_lastLitLeds;
        m_lastBlack = std::all_of(buffer.constBegin() + qMin(6, buffer.size()), buffer.constEnd(), [](char c) { return c == 0; });
    }
    return true; // RCX owns retry; never trigger the upstream recreate/dialog path.
}
void LedDeviceRcx::setColors(const QList<QRgb> &colors) {
    if (!colors.isEmpty()) ++m_captureUpdates;
    LedDeviceAdalight::setColors(colors);
}
void LedDeviceRcx::setLuminosityThreshold(int, bool update) {
    AbstractLedDevice::setLuminosityThreshold(0, update);
}
void LedDeviceRcx::setMinimumLuminosityThresholdEnabled(bool, bool update) {
    AbstractLedDevice::setMinimumLuminosityThresholdEnabled(false, update);
}
void LedDeviceRcx::requestFirmwareVersion() { emit firmwareVersion(m_firmware); emit commandCompleted(true); }
void LedDeviceRcx::publishStatus(bool connected) {
    QJsonObject obj{{"id", m_id}, {"connected", connected}, {"port", connected ? m_portName : QString()},
                    {"updated", QDateTime::currentMSecsSinceEpoch()}, {"pid", QCoreApplication::applicationPid()},
                    {"framesSent", double(m_framesSent)}, {"captureUpdates", double(m_captureUpdates)}, {"lastFrameBlack", m_lastBlack}, {"lastFrameLitLeds",m_lastLitLeds}};
    QSaveFile file(m_configDir + "/rcx-status.json");
    if (file.open(QIODevice::WriteOnly)) { file.write(QJsonDocument(obj).toJson()); file.commit(); }
}

void LedDeviceRcx::setBrightnessCap(int, bool update) { AbstractLedDevice::setBrightnessCap(100, update); }

QJsonObject LedDeviceRcx::liveController() const {
    if(!m_connected)return {};
    bool present=false;for(const auto &p:QSerialPortInfo::availablePorts())if(p.portName()==m_portName)present=true;
    if(!present)return {};
    return {{"id",m_id},{"port",m_portName},{"serial","RCX-AMB-"+m_id},{"model","RCX-AMBI-S300"},{"fw",m_firmware},{"max",m_maxLeds},{"count",1},{"m1size",32},{"m1ori","L"},{"m2size",24},{"m2ori","L"},{"total",m_colorsSaved.size()},{"standaloneBrightness",5},{"fallbackMode",2},{"framesSent",double(m_framesSent)},{"frameLeds",m_colorsSaved.size()},{"lastFrameLitLeds",m_lastLitLeds},{"lastFrameBlack",m_lastBlack},{"updated",double(m_lastFrameAt)}};
}
