/*
 * SoundVisualizer.cpp
 *
 *	Created on: 11.12.2011
 *		Project: Lightpack
 *
 *	Copyright (c) 2011 Mike Shatohin, mikeshatohin [at] gmail.com
 *
 *	Lightpack a USB content-driving ambient lighting system
 *
 *	Lightpack is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	Lightpack is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.	If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <QTime>
#include "Settings.hpp"
#include "SoundVisualizer.hpp"
#include <cmath>

/*
	_OBJ_NAME_	: class name prefix
	_LABEL_		: name string to be displayed
	_BODY_		: class declaration body
*/
#define DECLARE_VISUALIZER(_OBJ_NAME_,_LABEL_,_BODY_) \
class _OBJ_NAME_ ## SoundVisualizer : public SoundVisualizerBase \
{\
public:\
_OBJ_NAME_ ## SoundVisualizer() = default;\
~_OBJ_NAME_ ## SoundVisualizer() = default;\
\
static const char* name() { return _LABEL_; };\
static SoundVisualizerBase* create() { return new _OBJ_NAME_ ## SoundVisualizer(); };\
\
bool visualize(const float* const fftData, const size_t fftSize, QList<QRgb>& colors);\
_BODY_\
};\
struct _OBJ_NAME_ ## Register {\
_OBJ_NAME_ ## Register(){\
	visualizerMap.insert(vizID, SoundManagerVisualizerInfo(_OBJ_NAME_ ## SoundVisualizer::name(), _OBJ_NAME_ ## SoundVisualizer::create, vizID));\
	++vizID;\
}\
};\
_OBJ_NAME_ ## Register _OBJ_NAME_ ## Reg;

using namespace SettingsScope;

namespace {
	static QMap<int, SoundManagerVisualizerInfo> visualizerMap;
	static int vizID = 0;
}

SoundVisualizerBase* SoundVisualizerBase::createWithID(const int id)
{
	QMap<int, SoundManagerVisualizerInfo>::const_iterator i = visualizerMap.constFind(id);
	if (i != visualizerMap.cend())
		return i.value().factory();
	qWarning() << Q_FUNC_INFO << "failed to find visualizer ID: " << id;
	return nullptr;
}

void SoundVisualizerBase::populateNameList(QList<SoundManagerVisualizerInfo>& list, int& recommended)
{
	list = visualizerMap.values();

	if (list.size() > 0)
		recommended = list[0].id;
}

#pragma region Prismatik
DECLARE_VISUALIZER(Prismatik, "Prismatik (default)",
public:
	void clear(const int numberOfLeds);
private:
	QList<int> m_peaks;
	const int SpecHeight = 1000;
);

bool PrismatikSoundVisualizer::visualize(const float* const fftData, const size_t fftSize, QList<QRgb>& colors)
{
	size_t b0 = 0;
	bool changed = false;
	for (int i = 0; i < colors.size(); i++)
	{
		float peak = 0;
		size_t b1 = pow(2, i*9.0 / std::max(1,colors.size() - 1)); // 9 was 10, but the last bucket rarely saw any action
		if (b1 > fftSize - 1) b1 = fftSize - 1;
		if (b1 <= b0) b1 = b0 + 1; // make sure it uses at least 1 FFT bin
		for (; b0 < b1; b0++)
			if (peak < fftData[1 + b0]) peak = fftData[1 + b0];
		int val = sqrt(peak) * /* 3 * */ SpecHeight - 4; // scale it (sqrt to make low values more visible)
		if (val > SpecHeight) val = SpecHeight; // cap it
		if (val < 0) val = 0; // cap it

		if (m_frames % 5 == 0) m_peaks[i] -= 1;
		if (m_peaks[i] < 0) m_peaks[i] = 0;
		if (val > m_peaks[i]) m_peaks[i] = val;
		if (val < m_peaks[i] - 5)
			val = (val * SpecHeight) / m_peaks[i]; // scale val according to peak

		QRgb color = 0;
		if (Settings::isLedEnabled(i)) {
			QColor from = m_isLiquidMode ? QColor(0, 0, 0) : m_minColor;
			QColor to = m_isLiquidMode ? m_generator.current() : m_maxColor;
			interpolateColor(color, from, to, val, SpecHeight);
		}

		changed = changed || (colors[i] != color);
		colors[i] = color;
	}
	m_frames++;
	return changed;
}

void PrismatikSoundVisualizer::clear(const int numberOfLeds) {
	m_peaks.clear();
	for (int i = 0; i < numberOfLeds; ++i)
		m_peaks << 0;
}
#pragma endregion Prismatik



#pragma region TwinPeaks
DECLARE_VISUALIZER(TwinPeaks, "Twin Peaks",
private:
    double m_level = 0;
);
bool TwinPeaksSoundVisualizer::visualize(const float* const fftData, const size_t fftSize, QList<QRgb>& colors)
{
    // Capture normalizes the complete spectrum before bass filtering and user
    // sensitivity. Both arms share this relative beat level.
    double energy=0;
    for(size_t i=1;i<fftSize;++i)energy+=double(fftData[i])*fftData[i];
    const double target=qBound(0.0,std::sqrt(energy)/0.12,1.0);
    m_level+=(target-m_level)*(target>m_level?0.75:0.30);
    if(target==0 && m_level<0.015)m_level=0;
    const int arm=(colors.size()+1)/2;
    const int lit=qBound(0,int(std::ceil(m_level*arm-0.01)),arm);
    const QColor base=m_isLiquidMode?m_generator.current():m_maxColor;
    bool changed=false;
    for(int i=0;i<colors.size();++i){
        const int distance=qMin(i,colors.size()-1-i);
        QRgb color=0;
        if(distance<lit){
            // A visible base at the origin, brighter tips; silence remains exact black.
            const double gain=0.45+0.55*double(distance+1)/qMax(1,arm);
            color=qRgb(qRound(base.red()*gain),qRound(base.green()*gain),qRound(base.blue()*gain));
        }
        changed|=colors[i]!=color;colors[i]=color;
    }
    return changed;
}
#pragma endregion TwinPeaks
