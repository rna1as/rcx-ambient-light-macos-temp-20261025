// RCX additions, GPL-3.0-or-later.
#pragma once
#include "LedDeviceAdalight.hpp"
#include <QMap>
#include <QJsonObject>
class LedDeviceRcx : public LedDeviceAdalight {
    Q_OBJECT
public:
    LedDeviceRcx(const QString &id, const QString &configDir);
    ~LedDeviceRcx() override;
    QString name() const override { return QStringLiteral("RCX Ambient Light Premium"); }
    int maxLedsCount() override { return 350; }
    QString configuredId() const {return m_id;}
    QJsonObject liveController() const;
public slots:
    void open() override;
    void close() override;
    void setColors(const QList<QRgb> &colors) override;
    void setBrightnessCap(int, bool update = true) override;
    void setLuminosityThreshold(int, bool update = true) override;
    void setMinimumLuminosityThresholdEnabled(bool, bool update = true) override;
    void requestFirmwareVersion() override;
protected:
    bool writeBuffer(const QByteArray &buffer) override;
private:
    int m_maxLeds = 300;
    void discover();
    void accept(QSerialPort *port, const QMap<QString, QString> &identity);
    void disconnected();
    void publishStatus(bool connected);
    void clearProbes();
    QString m_id, m_configDir, m_firmware, m_lastPort;
    QString m_legacyID;
    QTimer *m_retry;
    QMap<QSerialPort *, QByteArray> m_probes;
    QMap<QSerialPort *, QByteArray> m_challenges;
    QMap<QSerialPort *, QMap<QString,QString>> m_identities;
    bool m_running{false}, m_connected{false};
    quint64 m_framesSent{0};
    quint64 m_captureUpdates{0};
    bool m_lastBlack{true};
    int m_lastLitLeds{0};
    qint64 m_lastFrameAt{0};
};
