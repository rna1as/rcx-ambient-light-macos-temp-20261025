// RCX additions, GPL-3.0-or-later. Native Windows system-audio capture; no BASS dependency.
#pragma once
#include "SoundManagerBase.hpp"
#include <QTimer>
#include <deque>
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include "RcxAudioLevel.hpp"
#include "RcxAudioVolumeMonitor.hpp"
#include <memory>
class RcxWasapiSoundManager : public SoundManagerBase {
    Q_OBJECT
    QTimer m_timer;
    IMMDeviceEnumerator *m_enumerator=nullptr;
    IAudioClient *m_client=nullptr;
    IAudioCaptureClient *m_capture=nullptr;
    std::unique_ptr<RcxAudioVolumeMonitor> m_volumeMonitor;
    RcxAudioLevel m_audioLevel;
    QByteArray m_volumeState;
    QElapsedTimer m_volumeCheck;
    QElapsedTimer m_levelClock;
    QElapsedTimer m_gainSettle;
    WAVEFORMATEX *m_format=nullptr;
    bool m_com=false;
 QString m_endpointId;
 QElapsedTimer m_endpointCheck;
    std::deque<float> m_samples;
    QElapsedTimer m_lastPacket;
    void releaseCapture();
public:
    explicit RcxWasapiSoundManager(QObject *parent=nullptr);
    ~RcxWasapiSoundManager() override;
    void start(bool enabled) override;
    double sampleRate() const override {return m_format?m_format->nSamplesPerSec:44100.0;}
protected:
    bool init() override;
    void populateDeviceList(QList<SoundManagerDeviceInfo>& devices,int& recommended) override;
    void updateFft() override;
};
