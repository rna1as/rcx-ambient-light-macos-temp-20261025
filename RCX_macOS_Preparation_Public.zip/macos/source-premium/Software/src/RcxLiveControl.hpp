// RCX local runtime control, GPL-3.0-or-later. Native UI only, no web UI.
#pragma once
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QTimer>
#include <QSharedPointer>
#include <QCoreApplication>
#include <functional>
#include "../../RCXAuth/auth_qt.hpp"
class RcxLiveControl:public QObject {
    QTcpServer server; QString path; QByteArray token;
public:
    RcxLiveControl(QObject *owner,const QString &dir,std::function<QJsonObject(QString)> handle):QObject(owner),path(dir+"/rcx-control.json"),token(rcxRandom(32).toHex()) {
        if(token.size()!=64||!server.listen(QHostAddress::LocalHost,0))return;
        QSaveFile f(path);if(!f.open(QIODevice::WriteOnly)){server.close();return;}
        f.write(QJsonDocument(QJsonObject{{"schema",1},{"port",int(server.serverPort())},{"token",QString::fromLatin1(token)},{"pid",QCoreApplication::applicationPid()}}).toJson());if(!f.commit()){server.close();return;}
        connect(&server,&QTcpServer::newConnection,this,[this,handle]{while(server.hasPendingConnections()){
            auto *socket=server.nextPendingConnection();auto buffer=QSharedPointer<QByteArray>::create();
            connect(socket,&QTcpSocket::disconnected,socket,&QObject::deleteLater);
            QTimer::singleShot(3000,socket,[socket]{socket->disconnectFromHost();});
            connect(socket,&QTcpSocket::readyRead,this,[this,socket,buffer,handle]{
                buffer->append(socket->readAll());if(buffer->size()>4096){socket->disconnectFromHost();return;}
                if(!buffer->contains('\n'))return;
                auto request=QJsonDocument::fromJson(buffer->left(buffer->indexOf('\n'))).object();
                QJsonObject reply{{"ok",false},{"error","Unauthorized"}};
                if(request["token"].toString().toLatin1()==token)reply=handle(request["command"].toString());
                reply["pid"]=QCoreApplication::applicationPid();socket->write(QJsonDocument(reply).toJson(QJsonDocument::Compact)+'\n');socket->disconnectFromHost();
            });
        }});
    }
    ~RcxLiveControl()override{QFile::remove(path);}
};
