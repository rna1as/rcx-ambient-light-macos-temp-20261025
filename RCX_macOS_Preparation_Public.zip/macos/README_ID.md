# RCX Ambient Light untuk macOS — persiapan kandidat

Status: source dan alur build disiapkan di Windows. Belum ada `.app`/DMG final, tanda tangan Developer ID, notarization, atau pengujian runtime di Mac. Jangan kirim sebagai rilis produksi sebelum checklist Mac lulus.

## Dasar dan pemisahan

- Budget memakai source Windows 2.8.0; Premium memakai 2.9.0, termasuk empat controller, nama controller, Sinkron semua, brightness/LED pada controller terpilih, dan perbaikan warna efek.
- `source-budget/` dan `source-premium/` di direktori **macos ini** adalah snapshot terpisah. Folder Windows asli, `release/`, `evidence/`, backups dan vault tetap di luar proses build.
- Workspace asal tidak memiliki `.git`; tidak ada cabang yang bisa dipakai. Bila nanti diimpor ke Git, gunakan cabang `macos-port` dan jangan gabungkan output Mac ke rilis Windows.
- `BASELINE.json` mencatat 14.074 file sebelum perubahan, lengkap dengan ukuran/hash. Backups tidak dipindai; vault tidak dibuka atau dipindahkan. Laporan baru hanya di `macos/reports/`.
- Firmware bersifat sama pada semua OS. Snapshot firmware masing-masing SKU dipertahankan byte per byte; tidak diseragamkan. Premium mempertahankan WebUI terbaru 19 Oktober: Single Color/color wheel, Effects, sumber PC/WebUI, SSID scan, AP+station, bahasa, OTA, migrasi preferensi dan EEPROM terpisah. Budget mempertahankan firmware SKU-nya sendiri. Tidak ada firmware/flasher di DMG pembeli dan tidak diperlukan flash untuk menyiapkan aplikasi Mac.

## Target dan dependensi

| Target | Peran | Status di Windows |
|---|---|---|
| `Software/math`, `grab`, `src` | Runtime Qt, capture, efek, autentikasi RCX | source disiapkan; build Mac belum dijalankan |
| `RCXDesktop` | Konfigurator widget native | source disiapkan; build Mac belum dijalankan |
| `native/RCXPlatform.pro` | Layar Qt dan USB serial `/dev/cu.*` | build/test Mac tertunda |
| `native/RCXLauncher.pro` | Finder launcher dan setup pertama | build/test Mac tertunda |
| `RCXSetup` | Backend konfigurasi/preset yang sudah ada | tes offline dan kompilasi Darwin, lihat laporan |
| `RCXFirmware` rainbow/off | Firmware controller, MAX=350 | arsip source dipertahankan; tidak dibangun/diunggah oleh build Mac |

Gunakan Mac Intel untuk `x86_64`, atau Mac Apple Silicon untuk `arm64`. Diperlukan Xcode command-line tools, Python >=3.10, Go >=1.23, dan **Qt 5.15.x native dengan QtSerialPort serta qttools/lrelease** untuk arsitektur yang sama. Script menolak Qt 6 dan cross-build native Qt. Qt 5.15.2 Windows bukan SDK Mac; dukungan SDK Qt 5.15 ARM harus disediakan/dibangun dan divalidasi secara terpisah. Belum diklaim universal binary. Deployment minimum yang diajukan adalah macOS 12.0; kompatibilitas aktual harus diuji dengan SDK/Qt terpilih.

Backend Mac menggunakan helper Qt untuk enumerasi layar dalam koordinat logis yang sama dengan runtime, USB UART dan baud 921600. Nonce menggunakan `SecRandomCopyBytes`; public trust root, certificate/proof dan identitas `RCX-AMBI-S300` tidak berubah. Helper hanya menerima query identitas/config, challenge autentikasi dan Tes Controller dari UI; tidak menerima flash/erase/setting firmware. USB vendor dibatasi ke CH34x/CP210x/FTDI. Perangkat dengan VID berbeda perlu investigasi pada Mac, bukan perubahan identitas.

## Menyiapkan folder untuk Mac

Cara ringkas: pindahkan `RCX_macOS_Preparation.zip` ke Mac dan ekstrak. ZIP sudah mengecualikan output/cache, baseline produksi, backups, paket Windows dan vault. Lihat `PREPARATION_SHA256SUMS.txt` di workspace asal untuk memeriksa integritas arsip. Status deklarasi firmware Budget 1.7.0 vs Premium/produksi 1.7.2 dijelaskan di `FIRMWARE_STATUS.md`.

Alternatif tanpa Mac pribadi: repo GitHub sementara khusus untuk persiapan macOS dapat memakai `.github/workflows/build-macos.yml`. Workflow hanya menjalankan pada perubahan `macos/**` atau saat `workflow_dispatch`, memakai runner standar `macos-15-intel`, dan mengunggah kandidat Budget/Premium selama 14 hari. Ekstrak isi ZIP sehingga folder `macos/` berada pada root repo, dorong ke GitHub, lalu jalankan/lihat tab Actions. Setelah unduh DMG, verifikasi SHA-256. Workflow tidak notarize atau membuktikan uji hardware. Repo publik berarti snapshot source firmware dan aplikasi menjadi publik; workflow tidak mensyaratkan repo publik. Hindari menaruh vault, identitas privat, bukti produksi atau paket Windows pada repo sementara. Hapus repo setelah Anda mengunduh artefak dan log yang diperlukan.

Salin **seluruh folder macos** ke Mac, kecuali `cache/`, `build/`, `artifacts/`, `reports/` dan `BASELINE.json` (yang terakhir hanya dibutuhkan untuk audit workspace asal). Tidak perlu menyalin `release/`, `backups/`, vault, pointer vault, atau bukti produksi. `source-*/RCXBuild/licenses` dan notices sudah disalin sehingga build Mac tidak membaca folder Windows asli. Jangan menjalankan `port_sources.py` lagi: itu catatan transformasi sekali dari snapshot Windows, bukan langkah build.

Di terminal Mac, masuk ke folder macos hasil salinan:

```bash
xcode-select --install  # hanya jika command-line tools belum ada
python3 --version
go version
"$HOME/Qt/5.15.2/clang_64/bin/qmake" -query QT_VERSION
```

Ganti lokasi Qt dengan SDK yang benar. Pada Apple Silicon, gunakan SDK native ARM yang telah disediakan; jangan memakai direktori Intel `clang_64` tanpa memverifikasi arsitektur.

Build kandidat Intel, pada Mac Intel:

```bash
python3 build_macos.py --sku budget --arch x86_64 --qt "$HOME/Qt/5.15.2/clang_64"
python3 build_macos.py --sku premium --arch x86_64 --qt "$HOME/Qt/5.15.2/clang_64"
```

Build kandidat ARM, pada Mac Apple Silicon, dengan lokasi SDK native Anda:

```bash
python3 build_macos.py --sku budget --arch arm64 --qt /absolute/path/to/qt5-arm64
python3 build_macos.py --sku premium --arch arm64 --qt /absolute/path/to/qt5-arm64
```

Setiap build memakai work directory baru dan menghasilkan `artifacts/<sku>/<arch>/<UTC timestamp>/`: `.app`, DMG kandidat, `BUILD_STATUS.json` dan checksum. Build tidak membuka controller atau menjalankan aplikasi runtime. Tes Go yang dijalankan hanya offline. Salin log terminal untuk diagnosis jika kompilasi native gagal. Tidak ada fallback ke builder/installer Windows.

## Signing dan notarization

Kandidat default memakai ad-hoc signing untuk pengujian lokal. Untuk distribusi gunakan Developer ID Application milik Anda dan profil notarytool yang sudah disimpan di Keychain; kredensial tidak masuk source:

```bash
python3 build_macos.py --sku premium --arch x86_64 \
  --qt "$HOME/Qt/5.15.2/clang_64" \
  --sign-identity 'Developer ID Application: YOUR NAME (TEAMID)' \
  --notary-profile RCX-NOTARY
```

Script deploy framework/plugin Qt dengan macdeployqt, memeriksa CPU binary, menandatangani nested Mach-O/framework lalu bundle, mengirim app dan DMG ke notarytool, serta staple/validate. Penggunaan Keychain dan pengiriman notaris hanya terjadi saat perintah tersebut Anda jalankan di Mac. Lihat [Qt deployment](https://doc.qt.io/qt-6.5/macos-deployment.html) untuk konsep macdeployqt dan [alur notarization Apple](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow). Opsi macdeployqt yang dipakai script tersedia pada Qt 5; halaman referensi Qt di atas menjelaskan deployment versi lebih baru, bukan klaim kompatibilitas port Qt 6.

## Memasang dan memakai

1. Mount DMG dan seret aplikasi ke Applications. Budget dan Premium mempunyai nama/bundle ID berbeda.
2. Buka aplikasi dari Finder. Pertama kali, konfigurator native akan muncul. Sambungkan controller uji dan pilih susunan/preset, lalu Simpan dan Jalankan.
3. Berikan Screen Recording pada aplikasi RCX di System Settings > Privacy & Security, lalu tutup dan buka kembali. Audio opsional memerlukan izin input audio yang sesuai.
4. Pengaturan runtime memanggil `rcx-backend` dalam bundle yang sama; tidak memakai executable Windows. Untuk membuka setup manual: `"/Applications/RCX Ambient Light Premium.app/Contents/MacOS/RCX_Launcher" --configure`.
5. Konfigurasi Budget: `~/Library/Application Support/RCX Ambient Light/`; Premium: `~/Library/Application Support/RCX Ambient Light Premium/`. Worker memakai `Controllers/<DeviceID>`. Tidak mengimpor profil/identitas produksi Windows secara otomatis.
6. Autostart tidak diaktifkan oleh installer. Jika diperlukan setelah QA, tambahkan aplikasi melalui Login Items macOS. Jalankan hanya satu aplikasi untuk controller USB yang sama.
7. Untuk uninstall, tutup aplikasi lalu hapus `.app` dari Finder. Konfigurasi pengguna tetap ada; hapus sendiri hanya bila memang diinginkan.

## Batas yang masih harus diselesaikan di Mac

Capture memakai backend MacAVFoundation/CoreGraphics yang sudah ada di source, bukan Windows Desktop Duplication. API capture lama telah deprecated ([Apple CGDisplayCreateImage](https://developer.apple.com/documentation/coregraphics/cgdisplaycreateimage)); SDK/macOS terbaru dapat memerlukan migrasi ke ScreenCaptureKit. Belum ada klaim dukungan macOS 15/26 atau kelulusan kompilasi dengan SDK terbaru. Jika SDK menolak API tersebut, pekerjaan berikutnya adalah mengganti adapter capture dengan ScreenCaptureKit dan menjalankan ulang seluruh checklist, bukan menonaktifkan pemeriksaan SDK.

Audio Mac memakai backend AVFoundation yang sudah ada: ini input audio terpilih, **bukan WASAPI loopback Windows**. Kesetaraan system-audio, bass/sensitivity, volume independence, device switch dan auto-offset belum diverifikasi. Jangan mengiklankan semua perilaku audio Windows sebelum kasus itu diuji/diadaptasi. Device audio virtual memerlukan pengaturan tersendiri; tidak ada driver pihak ketiga yang otomatis dipasang.

Tanpa Mac/runner dan SDK Apple pada sesi ini, kompilasi/link Qt/Objective-C++, permission prompt, GUI, serial/hotplug, Retina/rotation, signing/notarization serta DMG mount/install belum dapat dibuktikan. Ikuti `MAC_TEST_CHECKLIST.md`; seluruh kotak tersebut tetap pending meskipun tes Go lulus.
