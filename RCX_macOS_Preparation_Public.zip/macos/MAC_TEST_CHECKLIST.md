# Verifikasi kandidat macOS

Semua langkah native/hardware di bawah **BELUM DIJALANKAN** pada sesi Windows. Catat Mac model, CPU, macOS, Xcode/SDK, Qt, Go, hash DMG dan hasil per SKU/arsitektur di laporan baru. Jangan menimpa `../evidence/` produksi.

## Build dan installer

- [ ] Build Budget 2.8.0 dan Premium 2.9.0 menggunakan `build_macos.py`; simpan log. Jika SDK menolak capture API lama, migrasikan ScreenCaptureKit sebelum melanjutkan.
- [ ] `lipo -archs` semua binary/framework cocok dengan target; tidak memuat DLL/EXE/absolute dependency dari build host. Periksa `otool -L` runtime, helper, dan framework.
- [ ] `codesign --verify --deep --strict --verbose=2 "/path/to/App.app"`; untuk distribusi, `xcrun stapler validate` app dan DMG, dan `spctl --assess --type execute --verbose=2` app harus lulus.
- [ ] `hdiutil verify candidate.dmg`; mount DMG, salin ke Applications, launch dari Finder pada akun bersih tanpa Qt/Go/Python terpasang. Jangan menjalankan app di volume DMG read-only untuk pengujian install.
- [ ] Budget/Premium terpisah; tidak saling mengubah konfigurasi. Rename `.app` tetap bisa launch. Setup pertama, cancel, relaunch, setting ulang dan uninstall mempertahankan konfigurasi yang seharusnya.
- [ ] Source GPL, lisensi Qt/dependensi dan notices tersedia dalam bundle; tidak ada vault/pointer, identity records, ledger atau binary flasher/firmware produksi.

## Perilaku aplikasi dan capture

- [ ] Izin Screen Recording ditolak lalu diberikan kembali; tampilkan kegagalan yang jelas, reopen berhasil. Tes single display, Retina, monitor eksternal, scaling, portrait 90/270, origin negatif, perubahan refresh rate dan hotplug monitor.
- [ ] Sampling sisi/corner/arah cocok dengan strip; black bars dan black frame mematikan LED sesuai versi Windows; sleep/wake dan lock/unlock pulih.
- [ ] Enam efek, warna pilihan yang tetap aktif, kecerahan per mode, LED on/off, bahasa Indonesia/English, status koneksi, save/cancel setting ulang.
- [ ] Budget 27 preset; Premium 25 preset dan 75 inch/312 LED. Batas <=350 dan legacy MAX=300 tetap ditolak saat layout terlalu besar.
- [ ] Premium empat controller: Device ID stabil ketika nama port berubah, tidak berebut UART, rename, mode/brightness/on-off controller terpilih, Sinkron semua, exit/crash primary membersihkan worker.
- [ ] Tutup/quit tray dan launch ulang tidak menggandakan primary atau worker. Konfigurator yang ditutup tidak membunuh aplikasi lain.

## USB dan audio pada perangkat uji

- [ ] Gunakan controller khusus pengujian. Tes deteksi `/dev/cu.*`, autentikasi certificate+challenge, baud 921600, unplug/replug dan pemulihan; tidak memakai nama port sebagai identitas.
- [ ] Dengan alat observasi uji, pastikan open/close UART tidak memicu boot/reset yang tidak diharapkan. Tidak ada flash, erase, RCXSET, provisioning atau OTA dalam pengujian aplikasi.
- [ ] Tes Controller hanya dijalankan bila operator sengaja menekan tombol tersebut; verifikasi tiga kedip pada firmware yang mendukungnya.
- [ ] Mode suara: izin ditolak/diberikan, input yang tersedia, silence, bass/sensitivity, auto-offset, perpindahan device, perubahan volume, start/stop dan sleep/wake. Catat perbedaan AVFoundation vs audio Windows. System audio bukan fitur terverifikasi sampai ada jalur capture yang sesuai dan pengujian.
- [ ] Firmware Premium/WebUI tetap sama (tidak perlu flash): bila perangkat uji sudah memakai versi yang sesuai, cek Single Color, Effects, Settings/SSID, AP+station dan sumber PC/WebUI melalui browser tanpa mengubah kredensial/OTA produksi. Pengujian yang menulis preferensi hanya pada unit uji dengan izin operator.

Release baru boleh diberi status final setelah seluruh kasus relevan lulus dan batas dukungan OS/audio dinyatakan dengan jelas. Bukti Windows lama tidak membuktikan hasil Mac.
