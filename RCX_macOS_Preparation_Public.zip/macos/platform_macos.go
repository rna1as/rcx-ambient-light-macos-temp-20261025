//go:build darwin || rcx_portable_test

package main

import (
 "encoding/json"
 "errors"
 "fmt"
 "os"
 "os/exec"
 "path/filepath"
 "strings"
)

func binaryDir() string { p,e:=os.Executable();if e!=nil{panic(e)};return filepath.Dir(p) }
func installDir() string { return filepath.Join(binaryDir(),"..","Resources") }
func findPrismatikExe() string { return filepath.Join(binaryDir(),"RCX_Prismatik") }
func prismatikRunning() bool { _,e:=liveRequest(prismatikConfigDir(),"snapshot");return e==nil }
func startPrismatik(p string) error {
 if p=="" {return errors.New("runtime tidak tersedia")}
 c:=exec.Command(p,"--config-dir",prismatikConfigDir());c.Dir=binaryDir()
 if e:=c.Start();e!=nil{return e};go c.Wait();return nil
}
func stopPrismatik() { _,_=liveRequest(prismatikConfigDir(),"shutdown") }
func bundledInstallerPath() string { return "app-bundle" }
func ensurePrismatikInstalled()(string,error){p:=findPrismatikExe();_,e:=os.Stat(p);return p,e}
func cleanupLegacy()error{return nil}
func startup(enable bool,p string)error{return nil} // Login Items are explicitly managed by the Mac user.
func shortcuts()error{return nil}
func registerInstall()error{return nil}
func uninstall(){fmt.Fprintln(os.Stderr,"Quit RCX, then remove the app in Finder. User configuration is retained.")}
func showDesktopError(e error){fmt.Fprintln(os.Stderr,e)}
func closeSetupBrowser(){}
func reconfigureMode()bool{return true} // DMG installs an immutable app bundle; only user config is writable.
func runDesktop()error {
 p,e:=os.Executable();if e!=nil{return e}
 return exec.Command(filepath.Join(binaryDir(),"RCX_Configuration"),"--backend",p).Run()
}
func platformCommand(args ...string)([]byte,error){
 c:=exec.Command(filepath.Join(binaryDir(),"rcx-platform"),args...)
 var stderr strings.Builder;c.Stderr=&stderr
 out,e:=c.Output();if e!=nil{return nil,fmt.Errorf("platform helper: %w: %s",e,stderr.String())};return out,nil
}
func enumerateMonitors()([]Monitor,error){
 b,e:=platformCommand("monitors");if e!=nil{return nil,e}
 var native []struct {Name string `json:"name"`;X,Y,Width,Height int32;Rotation int;Primary bool}
 if e=json.Unmarshal(b,&native);e!=nil{return nil,e}
 var out []Monitor
 for i,m:=range native{ori:="landscape";if m.Height>m.Width{ori="portrait"};out=append(out,Monitor{Index:i,Name:m.Name,Primary:m.Primary,Orientation:ori,Rotation:m.Rotation,Width:m.Width,Height:m.Height,Rect:Rect{m.X,m.Y,m.X+m.Width,m.Y+m.Height}})}
 if len(out)==0{return nil,errors.New("tidak ada layar aktif")};return out,nil
}
func activeCOMPorts()map[string]bool {
 out:=map[string]bool{};b,e:=platformCommand("ports");if e!=nil{return out};var ports []string
 if json.Unmarshal(b,&ports)==nil{for _,p:=range ports{out[p]=true}};return out
}
func portExists(p string)bool{return activeCOMPorts()[p]}
func activePortExists(p string)bool{return portExists(p)}
func serialCommand(port,cmd string,bootWait bool)(string,error){
 b,e:=platformCommand("command",port,cmd);if e!=nil{return "",e};var response string;e=json.Unmarshal(b,&response);return response,e
}
