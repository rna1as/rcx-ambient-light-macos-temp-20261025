# Inventaris awal — 20 Oktober 2026

Inventaris lengkap dilakukan sebelum membuat snapshot/perubahan source: `BASELINE.json` (14.074 file, ukuran dan SHA-256; backups dikecualikan). Tidak ditemukan `.git` pada root atau tiga source tree aktif, maupun AGENTS.md pada root/ancestor/source aktif yang diperiksa. Instruksi operasional diambil dari README root, release/BUILD_NOTES.md, release/CHANGELOG.md, RCXBuild/BUILD_NOTES.md dan bukti pembaruan firmware WebUI. Sebagian README lama masih menyebut 2.5/2.8; versi SKU aktual menjadi acuan.

| Lokasi asal | Peran | Perlakuan |
|---|---|---|
| `source-budget/` | Source aplikasi Budget 2.8.0, 27 preset | snapshot tersendiri, tidak diubah |
| `source-premium/` | Source Premium 2.9.0, 25 preset, empat controller, WebUI 19 Oktober | snapshot tersendiri, tidak diubah |
| `source/` | Basis bersama/legacy dan firmware/flasher | diperiksa, tidak menjadi basis aplikasi SKU dan tidak diubah |
| `release/budget/`, `release/premium/` | Installer Windows pembeli, source/editor paket | tidak dibangun ulang atau ditimpa |
| `release/flasher/` | Paket produksi firmware/flasher | hanya inventaris hash, tidak dieksekusi/diubah |
| `evidence/` | Bukti pengujian/produksi yang ada | hash dibandingkan, tidak ditambah atau diubah |
| `backups/` | Arsip legacy dan toolchain lama | isi produksi tidak dipindai/disalin; Go compiler yang sudah ada hanya dipakai baca untuk tes offline |
| vault/identity/ledger | Otoritas produksi | tidak dibuka, dipindahkan atau dipakai oleh varian Mac |

Target Windows: runtime Qt `Software/math`, `grab`, `src`; Qt native configurator `RCXDesktop`; Go `RCXSetup`; `RCXPresetEditor`; firmware PlatformIO `rainbow`/`off`; produksi `RCXFlasher`/`RCXProvision`. Builder root `build_all.py` dan `refresh_premium_release.py` menulis rilis Windows sehingga tidak dipakai. Builder firmware/flasher juga tidak dipakai.

Target baru Mac: runtime Qt dari SKU masing-masing; configurator Qt dari SKU masing-masing; Go backend konfigurasi/preset; helper Qt layar/USB serial; launcher Finder; deployment framework Qt, signing, notarization opsional dan DMG. Editor/generator installer `.exe`, provisioning, vault dan flasher produksi bukan aplikasi pembeli Mac dan tidak dipindahkan.

Firmware platform: ESP8266 d1_mini, PlatformIO espressif8266@4.2.1, NeoPixelBus@2.7.0, baud 921600, batas 350 LED. Premium dan basis bersama mendeklarasikan 1.7.2-R/O. Budget snapshot berbeda dan tidak diam-diam di-upgrade. Source firmware Premium `src/main.cpp` SHA-256 `80b9cfd3e3283dac6c4158322efdbf5a5d39cbf7d147d91a487faf43c399ae0a`, WebUI `src/webui.hpp` `bbeb8fd614b52cf58ad551153afbb9936a0dcbc368880bf7120168e986bad426`. Source firmware adalah kontrak yang dipertahankan, bukan bukti firmware controller yang terhubung. Controller tidak diakses untuk memastikan versi unit fisik.

Perubahan port hanya pada snapshot macos: ganti RNG BCrypt dengan Security.framework tanpa mengganti trust root/protokol; backend Windows diganti adapter Qt lintas platform; konfigurasi user di Application Support; launcher/metadata bundle; panggilan setting ulang; pemantauan parent worker POSIX; hilangkan AVX2 wajib dan resource/link Windows pada target Mac. Logika runtime/preset/layout/efek yang lain diwarisi dari SKU masing-masing. Lihat README untuk batas parity capture/audio dan pengujian native yang masih tertunda.
